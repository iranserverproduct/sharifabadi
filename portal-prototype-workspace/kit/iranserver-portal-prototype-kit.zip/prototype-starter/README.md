# HTML prototype starter (Portal look)
- `tokens.css` — every colour (primitive + semantic), gap, radius from Uikit-V3 as CSS variables (generated from `../design-system/tokens.json`).
- `portal.css` — shell (header 68px, body, white card radius 8), Button (42px, Primary/Tonal/Outline/Text/Link, loading, disabled), Input (default/focus/error/disabled, required *), Tag/Chip, service-filter tiles, tabs, table, alert, wizard stepper, radio-card.
- `example-service-list.html`, `example-login-form.html` — worked examples (compare with `../reference-screens/`).
Use: copy the two CSS files into the prototype (or inline them in an artifact), keep `dir="rtl"`, font stack `'Peyda','Vazirmatn',Tahoma`. Peyda isn't on Google Fonts — Vazirmatn is the closest hosted fallback; if the user supplies Peyda files, embed them as @font-face data URIs.
Approximations (not measured, verify against Figma): tag text colours, wizard colours, tile layout, header contents.
