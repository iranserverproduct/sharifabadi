# IranServer Portal (user panel / "پنل کاربری") — layout & pattern guide

> Legend: facts below come from measured frames/screenshots unless marked **[?]** (inferred, verify in Figma before relying on it).

Source: Figma file **Portal** `1qrZx6L5Ug2eniRA8epD2U` (audited 2026-11-08). Pages: Dashboard, Finance, Support, Cart, Login/Signup, Host Purchase, Domain, One Click App, Service Management, Verified Email, Error, VPS/Block Storage, Affiliate programs, Page 20–22 (newest work: invoices, Cloud Services/Block Storage table, Whois), Temp, Flowkit. Libraries used: **Uikit V3** (+ Portal local components).

## 1. Shell (every Portal screen)
Frame widths: **Desktop 1920 · Tablet 842 (some 834) · Mobile 390 (some 360)**.
```
Page (V, gap 0, fill Surface/Surface Container)
 ├─ Header  → instance of UI Kit `Header` {Type=Header, Side=Dashboard, Device=Desktop|Tablet|Mobile, No Login=True}
 │            desktop: 1920×68, padding 16/300, fill Surface Bright, bottom stroke Outline/Outline Varient 2
 │            (logo at the right [RTL], then on the left: phone, cart badge, profile, «خرید جدید» Tonal button)
 └─ Body (V, gap 16, fill Surface Container)
      padding  Desktop [24, 240, 32|40, 240] · Tablet [24, 40, 32, 40] · Mobile [12, 16, 24, 16]
      content width Desktop 1440
      ├─ Status indicator row: breadcrumb (Breadcrumb Cell: Active / Not active) e.g. «نمای کلی › مدیریت سرویس»   (24px)
      └─ White card(s): fill Neutral/White (Surface Bright), radius 8, padding 24, inner gap 32 (V)
```
Desktop spacing between header and content ≈ 24; between stacked cards 16–24.

## 2. Page archetypes (copy these before inventing anything)
| Archetype | Reference frames | Structure |
|---|---|---|
| **List / management page** | `Cloud Services - Table` 36875:166787 (D), `Block Storage - Table (Mobile)` 36933:6920, `(Tablet)` 36933:36299, `Empty State` 36875:166745 / 36915:35645; `لیست سرویس‌ها` 13865:6966 | title «مدیریت سرویس» → toolbar (Search 42px + filter icon button + [Primary] «خرید …») → `Service Filter` category tiles (همه، هاست، خدمات ابری، سرور اختصاصی، SSL، CDN، سایر خدمات; tile = icon + label + count Tag) → Tabs (`Tab Cell` with counter tag «۱ سرویس فعال») → Table (`Table Cell`) → Pagination. Empty state = Illustration + 1–3 buttons (Table Type=Empty / Empty One Button …). |
| **Operation (kebab) menu** | `Operation menu` 36875:167098, `… - Block Storage` 36912:6480 (3 states: متصل/جدا شده/…) | vertical list of `Item Cell`; [?] destructive item last/red. Menu items depend on resource state (e.g. attach vs detach). |
| **Multi-step purchase / configuration wizard** | `Service configuration` 12533:26612, `Configuration + …` series (Host Purchase page), VPS/Block Storage purchase on «VPS, Block Storage» page | Wizard card (stepper: ثبت دامنه → پیکربندی سرویس → تایید سفارش → پرداخت; states Pass(green check)/Current/Next/Warning/Error/Disable) → Ticket/section cards (white, radius 8, padding 24, gap 80 between groups, 40 inner) → Radio Cards for choice (period, OS, domain type), collapsible sections (`Flavor Section`/`OS Section` State=Open/Close) → footer: [Primary] «ادامه خرید» + [Text] «مرحله قبل». Tablet/Mobile: **Summary Responsive** + bottom nav (`Bottom Nav - Tablet/Mobile`). Desktop has a right/left **Summary** column (440 wide: Type=One Item Not Selected / All Selected …). |
| **Detail / settings with grouped cards** | Domain page (Domain-Details-Desktop 19242:19463, DNS, Whois Information, SSL), `جزییات سرویس‌ها` 14418:14812 | Dashboard status card on top (Type=Active/Expiring/Pending…), then stacked setting cards each with title, state Tag, helper text and a Tonal/Outline action. Edit states (View / Edit / Loading / Error) are separate variants. |
| **Finance** | Invoice-unpaid/paid/cancelled/refund (Finance, Page 20), Wallet, Payment, Sidebar (payment method) | Invoice summary + payment `Sidebar` panel (467 wide) with Wallet row states, discount-code states, Offline/Online payment method; result pages Success/Error/Cancelled. |
| **Auth** | `login` 13730:14668 (+ Forget password, Reset, One-time link, Signup) | Split screen: **left 436px brand panel** (fill Primary/Primary, white logo + watermark) / right form column ~390 wide: H1 «ورود به پنل کاربری», Inputs with ` *`, link-button «رمزتان را فراموش کرده‌اید؟», captcha input, Checkbox «مرا بخاطر بسپار», row [Primary «ورود»][Tonal «ورود با لینک یکبار مصرف»], footer «حساب کاربری ندارید؟ ثبت نام». (RTL: brand panel is on the *left*.) |
| **Support / Ticket** | Support page (Ticket-AI flows), `Attach File`, Stars/Feedback | [?] not inspected in detail — components: Dropdown, Attach File, Text Area (send), Stars/Feedback; open Support frames before copying. |
| **Error pages** | `404` 11508:28675, `403`, `under_maintenace` | [?] not inspected in detail — open the frames before copying. |

## 3. Interaction conventions seen across the Portal
- **State coverage**: every flow is designed with Default · Loading · Empty · Error · Success (and Disabled / Rate-limited / Cooldown for fragile actions like wallet checks). A new screen is not done until these exist.
- **Responsive**: each desktop frame has Tablet (842) and Mobile (390/360) twins named `… [Tablet]` / `… [Mobile]`. Mobile: toolbar wraps, tabs and tables scroll horizontally, wizard becomes compact with bottom nav, cards go full-width, Primary button full-width at the bottom.
- **RTL**: Persian text right-aligned; the *first* reading item sits on the right; icons that imply direction are mirrored [?] (e.g. in the website slider the *left* arrow is the "next" control). Numbers in Persian digits (۱۲۳) for UI copy [observed in screenshots], Latin digits for IPs/technical values (`IP : 185.213.188.215`), prices «۷٬۹۹۰٬۰۰۰ تومان» with a thousands separator.
- **Feedback**: Toast for transient results (top), Alert for page-level conditions, inline Input error for fields, Modal for destructive/confirm flows (footer built from `Modal Cell` Type=Footer; exact button mix [?] check a Modal frame, e.g. Affiliate page `Modal` 35201:132401).
- **Price display**: Toman; discount as green Tag «۷۸٬۰۰۰ تومان تخفیف» above the price; prices are dynamic (never hard-code).
- **Status Tag mapping** (service lists): فعال → Success · در انتظار / در حال پرداخت → Warning · در حال ایجاد → Info · معلق/لغو شده → Error/Gray.
- **Cross-sell / Gift**: `Gift-Button` badge in header; one-click-app, add-ons as selectable cards (`App-Card`, `Plugin-Card`, `CloudDisk-Card` with Selected/Active toggles).

## 4. Business constraints that shape Portal designs
- Billing model: plan-based; the user picks a plan, then configures (OS/location/period/addons), pays from wallet/invoice. Don't invent per-second/usage-based billing UI unless the PRD says so.
- Domain `.ir` (IRNIC) has its own flows/states (IR vs International variants for Whois, Lock, DNS Security).
- Products with portal surfaces today: Host, Domain, SSL, CDN, Cloud VPS, Block Storage, Object Storage, GPU [verify before designing], One-Click Apps, Support/Ticket (with AI), Finance (wallet, invoices, tax), Affiliate («همکاری در فروش»), Verified Email / Whois / profile.
- See `reference-docs/` (users, design principles, patterns, website overview) for audience and product-architecture reasoning.
