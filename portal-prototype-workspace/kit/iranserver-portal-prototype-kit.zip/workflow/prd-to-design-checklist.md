# PRD → Portal design: the workflow and what must be checked first

Use this whenever a PM hands over a PRD and asks for a design/prototype "matching the IranServer Portal".
Principle: **don't draw first.** Understand → reuse → design → cover states → verify. Tell the user what is fact, what is your assumption, what is unknown (mark unknowns in [brackets]; never invent components or product facts).

## A. Read the PRD — extract (write this back to the user in ≤15 lines)
1. **Goal & user problem** (who: new buyer / existing customer / admin; which product: Host, Domain, VPS, Block Storage, GPU, SSL, CDN, Finance, Support …).
2. **Scope**: screens/flows affected; entry points (menu, service list kebab, dashboard card, notification); exit points.
3. **User states & permissions**: logged-in always; verified email/phone? wallet balance? sub-accounts/roles? `.ir` vs international? trial/free?
4. **Data**: fields shown, units (GB, vCPU, تومان, ماه), formats, sort/filter/search, pagination limits, real-time/async operations (creation takes minutes → status Tags + Toast).
5. **Business rules**: pricing/billing cycle, discounts, limits/quotas, irreversible actions, cancellation/refund, dependencies (e.g. block storage must be in the same datacenter as the VPS).
6. **States to cover** (Portal norm): default · loading · empty · error (field / page / system) · success · disabled · rate-limited/cooldown · partial.
7. **Responsive**: Desktop 1920 (content 1440), Tablet 842, Mobile 390 — twins for each.
8. **Success metrics / analytics events** if any; **open questions** the PRD leaves.
Contradictions with the existing Portal behaviour → flag them, don't silently resolve.

## B. Pre-flight audit of what already exists (do this before any layout)
1. In the **Portal Figma file** find the closest archetype (`portal/portal-patterns.md` §2) and 1–2 recent reference frames (prefer Page 21/22 — newest conventions). Open them (screenshot + structure). Reuse only when the **UX responsibility** matches, not just the look.
2. In the **UI Kit** check every control you need exists (`design-system/components-catalog.md`). If something is missing: say so, propose a composition from existing parts first; a *new* component is built in the UI Kit (never ad-hoc in the page), named `Name=/Type=/Device=`, reviewed by the user, then placed as instances.
3. Check variables/text styles exist for every colour, gap, radius, font (`tokens.json`). Bind, never hard-code.
4. Check copy conventions in neighbouring screens (button verbs, tone: formal-polite Persian, e.g. «ادامه خرید», «مشاهده»…) and reuse labels. [No written microcopy guide exists — see gaps below.]

## C. Design
- Choose the archetype → compose from instances → fill with realistic Persian content (no lorem; real units/Toman).
- One Primary button per view; secondary = Tonal/Outline; tertiary = Text/Link. Inputs and buttons are 42px.
- Build Desktop first, then Tablet and Mobile twins; then the state frames (empty/loading/error/success).
- Prototype links: connect the happy path + 1 error path at least.

## D. Verify before showing
Screenshot every frame; check RTL alignment, overflow/truncation, tokens bound (no raw hex), instances not detached, naming (`Page – Desktop|Tablet|Mobile`, state suffix), touch targets on mobile, contrast. Report in 3–5 lines: what you built, which assumptions you made, what's unverified.

## E. Questions worth asking the PM (only the ones the PRD doesn't answer)
- Which user segment sees this and what do they do *just before and just after*?
- Is any pricing/limit dynamic from the backend (so we must not hard-code)?
- What happens on failure/timeouts; what's the support fallback?
- Is a new component really needed, or does an existing archetype fit?
- Any legal/finance constraints (tax, invoices, `.ir` IRNIC rules)?

## F. Gaps in THIS kit — worth a quick check at the start of the first session in the new account
These weren't fully audited (honest list):
1. **Library access/publish state** — confirm the new Figma account can open `Portal` (`1qrZx6L5Ug2eniRA8epD2U`) and `Uikit-V3` (`0uxzan8L6i5bMtqwdjjOlX`) and that Uikit-V3 is enabled as a library in Portal; imports only work for *published* components.
2. **Modal / Toast / Alert / Empty State usage** inside Portal frames (copy rules, button mix) — only the components were catalogued.
3. **Support/Ticket, Finance, Error archetypes** — catalogued by name/screenshot, not measured in detail.
4. **Microcopy & tone guide** — doesn't exist as a document; infer from screens.
5. **Accessibility/contrast targets, analytics events, role/permission model** — not documented anywhere I could see.
6. **Portal-local components** (Service Filter, Summary, Wallet…) live in the Portal file; their publish state/keys weren't checked.
7. **GPU product in the Portal** — the GPU plan flow exists on the website (`iranserver.com/vps/gpu`); its Portal surfaces [unverified].
