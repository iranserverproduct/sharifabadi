# IranServer Website — Card Architecture

This document consolidates the current understanding of IranServer's card patterns into a conceptual architecture for use in future PRD and design-analysis work. It is **not** a Figma component architecture, not a recommendation to refactor the UI Kit, and not a judgment that the current structure is optimal.

## Evidence Base and Limits

**Sources used**
- Two Pillar card examples: a Hosting product card (WordPress Hosting) and an enterprise/government package card.
- PDP plan card examples: three desktop cards and a stacked mobile set, shown as UI Kit examples with placeholder content.
- `patterns.md` (version 1, based on two PDPs only).
- Earlier page-level screenshots: Hosting Pillar, VPS Pillar, WordPress PDP, Germany VPS PDP.
- The Button documentation.

**Limits**
- Screenshots are low resolution and some text is unreadable.
- The PDP card examples use placeholder content, so their text is not evidence of real offers.
- There is no access to the actual UI Kit structure.
- Pillar evidence for the assisted card is a single instance.

**Evidence labels used below**
- *(documented)*: stated in the briefs provided.
- *(visual)*: observed in screenshots.
- *(hypothesis)*: interpretation, not confirmed.
- *(unknown)*: cannot be determined from current evidence.

---

## 1. Card Families

Two card families are treated separately, because their UX responsibilities differ even where they look similar.

| | Pillar Product / Offer Cards | PDP Product / Plan Cards |
|---|---|---|
| Journey stage | Discovery, category understanding, product or solution selection | Product evaluation, plan comparison, plan selection |
| Primary user decision | Which product or offer fits my need? | Which plan or offer within this product do I want? |
| Typical next step | Product page or plan exploration (self-service), or a consultation request (assisted) | Purchase flow, configuration flow, or cart |
| Conversion model | Self-service or assisted, depending on the card | Self-service within the card |
| Meaning of price | A preview that helps selection | A decision-level price (see 1.2) |

### 1.1 Pillar Product / Offer Cards

**Role** *(documented)*
Appear on Pillar / Category pages. They help users move from a broad category to a relevant product or offer, and then to a next decision step.

**Primary User Decision**
Which product, offer or solution is relevant to me?

**Typical Next Step** *(documented)*
- Hosting-style card: view the product's plans (self-service progression).
- Enterprise-style card: request a consultation (assisted progression).

**Shared Anatomy** *(documented; visual in both examples)*
1. Identification: icon or visual, plus a product, package or category label.
2. Value communication: a main title, which in both examples reads as an audience or fit statement.
3. Commercial context: a price, with optional prefix, discount or explanation.
4. Primary action: a CTA that reflects the expected next step.
5. Supporting information: a lower region summarizing attributes, capabilities or benefits.

Not every card is expected to contain every area.

**Optional Capabilities**
- Discount badge
- Price prefix ("From")
- Price explanation line
- Secondary text action
- Divider
- Per-item information icons
- Visible card border
- Tinted icon tile
- Horizontal attribute row or vertical benefit list in the supporting region

I cannot tell which of these are configurable properties of one component and which belong to separate compositions *(unknown)*.

**Conversion Model**
Both modes exist *(documented)*. The same card slot can carry a self-service CTA or an assisted one, and the example cards look visually similar, so the label text carries the difference *(visual)*.

**Known Variations**
- Hosting product card: starting price, discount badge, compact attribute row, self-service CTA *(visual)*.
- Enterprise/government card: audience-defined offer, fixed amount with an explanation line, assisted CTA, secondary text link, vertical benefit list *(visual)*.
- Product grids on the Hosting Pillar and VPS Pillar pages use cards for products and variants, which are probably the same family, but I haven't verified that *(hypothesis)*.
- In the earlier Hosting Pillar screenshot, one card appeared to have a blue outline and a small tag. Whether this is a recommendation state or something else is not confirmed *(unknown)*.
- No responsive (mobile) Pillar card examples have been provided *(unknown)*.

**Relationship to Other Components** *(structural description only)*
- Button: card CTAs appear Tonal-looking in the examples, and the secondary link appears Text- or Link-like *(hypothesis, based on styling)*. The Button documentation lists "View Plans" as a typical Primary action, so this is an open tension (see Section 4).
- Pills/badges for labels and discounts.
- Icon tile.
- Information rows (icon plus text), with optional info icons.
- Divider.

**Known Unknowns**
- Whether the two examples are variants of one component, two components, or compositions of a shared base.
- Which page types the assisted card appears on.
- Whether other assisted/enterprise card examples exist.
- Whether price styling carries meaning or is uniform.
- Whether the info icons are interactive.

### 1.2 PDP Product / Plan Cards

**Role** *(documented)*
Appear on Product Detail Pages. They help users compare multiple options within one product and then enter purchase, configuration or cart.

**Primary User Decision**
Which plan or offer within this product should I choose?

**Typical Next Step** *(documented)*
Purchase flow, configuration flow, or shopping cart.

**Shared Anatomy** *(visual in desktop and mobile examples)*
1. Plan or model name, with small icons.
2. A server-type illustration or icon (desktop).
3. A short spec chip.
4. A product title.
5. Price with a billing unit and a one-line price explanation.
6. A discount or savings line.
7. A billing-period selector, shown as a two-option segmented control.
8. The main CTA, with a small caption under it.
9. A single starred row.
10. A grouped specification list under a "Service specifications" heading.

In both desktop and mobile examples the CTA comes before the detailed specification list *(visual)*.

**Optional Capabilities** *(documented as conditionally visible)*
- Promotional or recommendation badge
- Discount or savings text
- Chip
- Billing selector
- Extra specification group
- Expandable detail area (mobile)
- Supporting icons

**Conversion Model**
Self-service within the card *(documented)*. No assisted-sales action appears inside these cards *(visual)*. Any assisted path is a separate page-level pattern, such as the inline contact form on the Cloud PDP recorded in `patterns.md`.

**Known Variations**
- Three visual treatments appear in both layouts, and I am not assuming they are formal variants *(visual)*:
  - Plain: no visible border, no top badge, Tonal-looking CTA.
  - Emphasized: blue border, orange/yellow top badge, white background, Tonal-looking CTA.
  - Featured: blue border, light blue tint, green top badge, Primary-looking CTA.
- Badge labels are unreadable, so I do not map colors to meanings such as recommended, best price or special offer *(unknown)*.
- A fourth mobile card, "Server Auction," appears expanded with key-value spec rows. It may be a different offer type or an expanded state *(unknown)*.
- Desktop and mobile appear to be responsive adaptations of the same family *(documented direction; visual support)*.

**Relationship to Other Components** *(structural description only)*
- Button: Primary-looking on the featured treatment only, Tonal-looking otherwise *(hypothesis, based on styling)*.
- Chips/badges, a segmented control for billing, icons, information and check-style rows, grouped list headings, and an expandable area on mobile.

**Known Unknowns**
- Whether the three treatments are states, variants or separate compositions.
- Billing selector options, and whether selecting one changes the price and discount text.
- Whether the red-tinted icons in the second specification group mean something specific.
- The nature of "Server Auction."
- Whether the mobile expansion is inline or a sheet.
- Whether production pages match these kit examples.
- The identity of the small control at the top-left of the mobile frame.

### 1.3 Card-like Elements Not Covered

These have not been analyzed here, and nothing in this document should be read as assigning them to a family:
- Feature/benefit cards in advantages grids
- Related products and add-on tab cards
- Testimonial cards
- Blog article cards
- Plan comparison table columns

---

## 2. Shared Card Foundations

Only ideas that appear in **both** families are listed. Similarity is not treated as proof of a shared component.

### Shared visual foundations *(visual)*
- Stacked vertical layout inside a rounded container.
- Icon at the top, with center-aligned upper content on desktop.
- Pill-shaped labels and chips.
- Prominent price typography with the currency unit set smaller.
- A card-width CTA.
- A lower supporting-information region.

A visible border is **not** universally shared. It appears on the enterprise card and on the emphasized and featured PDP treatments, but not on the Hosting Pillar card in its crop, and it is unclear whether that crop cuts one off *(unknown)*.

### Shared information structure *(documented and visual)*
Identification → value statement → commercial context → primary action → supporting information.

The families add different elements to this order:
- PDP cards add selection controls and recommendation states.
- Pillar cards add an optional secondary text action and price explanation, and the PDP cards also show a price explanation line.

### Shared UI components *(structural, no component names assumed)*
- A CTA button.
- Pill-shaped badges and labels.
- Information rows with leading icons.
- Large price text.

Dividers, info icons and segmented controls are each observed in only one family and are not claimed as shared.

### Different UX responsibilities *(documented)*
- **Decision:** product or offer fit (Pillar) vs. plan choice within a product (PDP).
- **Price meaning:** a preview or commercial context (Pillar) vs. a decision-level price (PDP, hypothesis that it is tied to the billing selector).
- **Conversion:** self-service or assisted (Pillar) vs. self-service (PDP).
- **Supporting information depth:** compact (Pillar) vs. grouped, detailed lists (PDP).
- **State handling:** one candidate recommendation signal on Pillar, unconfirmed, vs. recommendation, emphasis and expanded states on PDP.
- **Mobile behavior:** not yet seen on Pillar, vs. a compact layout with expandable detail on PDP.

### Not claimed as shared
Billing selection, recommendation badges, and the assisted-sales model. Each has evidence in one family only.

---

## 3. Current Card Architecture (Conceptual)

The names below are working labels for the knowledge base. They describe UX responsibility and do not claim a Figma structure.

```
Card (conceptual parent only, not a component claim)
│
├─ Pillar Card family
│   ├─ Pillar Product Card         self-service progression       (2+ instances)
│   └─ Pillar Solution Card        assisted progression           (1 instance)
│
├─ PDP Plan Card family
│   └─ PDP Plan Card               self-service plan selection
│        treatments seen (not confirmed variants or states):
│          Plain / Emphasized / Featured
│
└─ Unclassified
    └─ Expanded "Server Auction" card (mobile)
```

| Name | Basis | Status |
|---|---|---|
| Pillar Product Card | Documented Hosting example, plus Pillar page grids (hypothesis) | Provisional |
| Pillar Solution Card | One enterprise/government example | Provisional, single instance |
| PDP Plan Card | Documented desktop and mobile examples | Provisional |
| Plain / Emphasized / Featured | Visual treatments only | Unconfirmed as states or variants |
| Server Auction card | One mobile example | Unclassified |

**Naming notes**
- **Pillar split:** The two Pillar cards differ on several axes at once: product vs. audience, self-service vs. assisted, starting price vs. package value, and horizontal attributes vs. a benefit list. With one assisted example I cannot say which axis defines the split. "Solution" reflects the audience-defined offer, not an established category.
- **No "Recommended" name:** I avoided it because badge labels are unreadable and recommendation meaning is unconfirmed.
- **Undecided:** Whether each family becomes one component with variants, a base with compositions, or separate components.

---

## 4. Implications for Existing Documentation

These are flags, not edits. No other file has been changed.

**`patterns.md`**
- **Plan Selection Entry** describes plan cards by content schema and a Cloud-only grid toggle. It does not mention the in-card billing selector or the emphasis/featured treatments.
- **Pricing Presentation** is recorded as an established shared pattern. That holds for placement, but card evidence shows price meaning differs: a starting price, a decision-level price, and an account charge with its own explanation.
- **Contact Sales / Consultation** records only the Cloud PDP inline form. The Pillar Solution Card is another assisted entry point, and its page location is unknown.

**Button documentation**
It lists "View Plans" as a typical Primary action and says to avoid multiple Primary buttons in one viewport. In card grids the CTAs look Tonal, with Primary appearing only on the featured PDP treatment. This may be a deliberate way of keeping Primary scarce, but that is unconfirmed, and the documentation gives Tonal no defined semantic role.

---

## 5. Rules for Future PRD Work

1. First identify whether the card supports **product discovery** or **plan selection**.
2. Prefer an existing card family when its UX responsibility matches.
3. Do not use a Pillar card because it visually fits a PDP, or the reverse.
4. Do not create a new card family for visual variation alone.
5. Identify product-specific requirements before extending the shared pattern.
6. If no existing family fits, flag it as a potential new pattern rather than silently inventing one.
7. Ask what the price represents (starting, per-period, or package) before reusing a pricing layout.
8. Choose card CTAs from the existing Button hierarchy per card state, and do not add card-specific button logic.
9. Check whether a mobile difference is a responsive adaptation before treating it as a separate component.

---

## 6. Open Questions That Could Change This Architecture

- Are the two Pillar examples variants of one component, or two components? More Pillar examples are needed, especially other enterprise or solution cards.
- Does a recommendation state exist on Pillar cards?
- Are the PDP treatments states, variants or compositions, and which card is the Default?
- How does the billing selector behave, and does it change the displayed price and discount?
- What is the "Server Auction" card, and is it a third family?
- Which Button variant do card CTAs use in the UI Kit, and is it intentional?
- Do production pages match the kit examples?
- Does a third card family exist for configuration or cart summaries? None has been seen yet.

---

*This document should be revised when the UI Kit structure, more Pillar examples, or production PDP evidence become available. Provisional names should not be treated as final component names.*
