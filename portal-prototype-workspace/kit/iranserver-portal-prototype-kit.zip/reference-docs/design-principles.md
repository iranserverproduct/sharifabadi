# IranServer Website — Design Principles

These principles are decision-making guidance for recurring product and UX questions on the IranServer website — not rigid UI rules. They are derived from IranServer's actual business context, documented tensions, and current product reality (`website-overview.md`, `users.md`, and validated design-tension discussions), not from generic UX conventions.

Each principle separates what is actually known from what is still assumption. Where evidence is weak, guidance is intentionally softer. These principles should evolve as research, analytics, and behavioral evidence become available — they are a current best understanding, not a final system.

A note on structure: one pattern — **consistency should not be treated as sameness** — recurs across several principles below rather than standing as a single rule. It is most explicit in Principle 5, but it also underlies Principles 3, 4, and 7.

---

## 1. Support the Current Business While Leaving Room for Cloud

### Principle
Design for the business IranServer has today; leave deliberate room for the business it may become.

### Why It Matters
Hosting & Domain currently represents a major share of traffic and purchase activity. Cloud is a genuine long-term direction, but it is currently a strategic aspiration — not a committed team objective, and not backed by KPIs or a confirmed timeline. Over-designing around an uncertain future state risks under-serving the business that actually sustains the company today.

### Current Evidence
- Hosting/Domain drives the current commercial base (internal product knowledge).
- Cloud's long-term direction is documented, but explicitly not yet an execution mandate (internal product knowledge).
- Cross-sell from Hosting/Domain to Cloud exists but has low visibility and priority (current implementation).
- No unified visual/verbal distinction currently exists between Hosting/Domain and Cloud — both use the same UI Kit and tone (current implementation).

### Design Guidance
- Default to serving today's core business well; treat cloud-forward moves as additive, not replacing what already works for Hosting/Domain.
- Where cloud needs distinct treatment (see Principle 5), let that emerge from product-specific requirements — not from a general push to "look more cloud-first."
- Cross-sell placement can be revisited deliberately, but any increase in prominence should be a considered decision, not an assumption that more visibility is automatically better.

### Avoid
- Restructuring the site as if IranServer is already, or is about to become, a cloud-native platform.
- Treating "the long-term direction is cloud" as license to deprioritize Hosting/Domain experience quality.
- Assuming low-visibility cross-sell is a problem to fix without evidence it's actually suppressing cloud growth.

### Confidence
Strong — supported by explicit, documented business context.

### Related Research Gaps
- No target or timeline exists for when cloud should meaningfully shift the website's emphasis.
- No evidence yet on whether current low-visibility cross-sell placement is a missed opportunity or appropriately calibrated.

---

## 2. Bring Value Justification Closer to the Price Decision

### Principle
Where price sensitivity is known and premium positioning is the strategy, don't make users go looking for the justification.

### Why It Matters
Hosting & Domain users have shown documented price sensitivity, while IranServer's strategy deliberately avoids competing on price — leaning on support and reliability instead. Today, pricing is presented relatively standalone, with value signals (support quality, uptime, reliability) appearing later in the page rather than at the moment of price evaluation.

### Current Evidence
- Price sensitivity is documented (questionnaire evidence).
- Premium positioning strategy is confirmed (internal product knowledge).
- Current page structure separates pricing from value justification (current implementation).
- Support-as-differentiator is a business *intention* — not yet validated as an established user perception, and not yet reinforced consistently enough across the experience to be assumed as "already working" (internal product knowledge).

### Design Guidance
- Consider surfacing trust/value signals closer to where price is evaluated, rather than relying on users to scroll further to find justification.
- Do not treat a single support-focused section as sufficient to establish premium positioning — reinforcement likely needs to span multiple touchpoints (messaging, proof points, service delivery), not just a page section.
- Any pricing-adjacent trust signal should be genuinely substantiated, not just placed nearby for effect.

### Avoid
- Assuming that simply relocating or adding a support blurb near pricing "solves" the price-sensitivity tension.
- Treating support quality as an already-proven competitive advantage in copy or design when user perception of it hasn't been validated.

### Confidence
Medium — the tension is well-documented, but the specific fix (proximity of value signals to price) is a reasonable hypothesis, not a validated solution.

### Related Research Gaps
- Relative weight of price vs. support/uptime/trust in actual purchase decisions is unknown.
- Whether users currently perceive IranServer as differentiated by support is unvalidated.

---

## 3. Match Page Structure to Actual Readiness to Convert

### Principle
Don't assume the same page structure fits every product's buying readiness — but don't change it without evidence either.

### Why It Matters
Every landing page, including Cloud Products, currently follows the same Hero → conversion CTA → education-later structure. This directly conflicts with the working assumption that Cloud users need more context before deciding. Right now, this is a structural/design-system pattern, not a data-validated behavior — for either side.

### Current Evidence
- The Hero-CTA-first pattern is applied uniformly across product categories, including Cloud (current implementation).
- No behavioral data exists (CTR, scroll depth, drop-off, section engagement) confirming whether Cloud users are ready to convert from the Hero or need education first (open question).
- For Cloud Server specifically, the Hero CTA already leads to Plan Selection before Configuration — not directly into the technical flow (current implementation) — but whether this sequence is optimal is unvalidated.

### Design Guidance
- Treat "conversion-first" as the current default, not a proven best practice for every product.
- Where a product's evaluation complexity clearly exceeds what a generic Hero can support (e.g. Cloud products requiring category education), it's reasonable to test structural variation — but this should be framed as a hypothesis to validate, not a redesign mandate.
- Prioritize instrumenting current pages (analytics on Hero CTA engagement, scroll depth) before restructuring based on assumption.

### Avoid
- Declaring either "conversion-first" or "education-first" a universal rule for Cloud Products.
- Redesigning Cloud landing pages around the education-first assumption without first checking whether current conversion-first pages are actually underperforming.

### Confidence
Medium — the mismatch between stated assumption and actual structure is clearly documented; the correct resolution is not.

### Related Research Gaps
- No behavioral data yet on Hero CTA performance for Cloud Products specifically.
- Whether the current Hero → Plan Selection → Configuration sequence for Cloud Server is optimal is unvalidated.

---

## 4. Prioritize Conversion Paths Intentionally, Not by Default Template

### Principle
When a page offers both self-service purchase and assisted sales, which one leads should be a decision — not an inherited default.

### Why It Matters
Many product pages expose direct purchase and contact-sales/consultation simultaneously. Today, direct purchase is consistently the primary visual action (primary button styling) and assisted sales is secondary — but this hierarchy comes from a shared UI pattern applied uniformly, not from a formal rule based on product complexity, contract size, or user needs.

### Current Evidence
- Direct purchase is the default primary path across pages; assisted sales is secondary (current implementation).
- There is informal understanding that higher-scale or higher-complexity needs should shift toward assisted sales, and some differentiation already happens in practice (internal product knowledge) — but no formal threshold or reusable rule exists (design gap).
- Page structure is currently driven by shared, reusable components rather than product-specific conversion strategy (current implementation).

### Design Guidance
- When designing or reviewing a product page, explicitly ask which path *should* be primary for that product/audience, rather than inheriting the default self-service-primary pattern automatically.
- Where informal signals already suggest assisted sales should lead (e.g. higher resource tiers, enterprise-adjacent products), it's reasonable to make that primacy explicit in the design — but document the reasoning, since no formal threshold exists yet.
- This is a good candidate for an eventual shared rule (e.g. a plan/resource threshold that shifts primary path) — but until validated, treat each case deliberately rather than assuming the pattern generalizes.

### Avoid
- Applying direct-purchase-as-primary to every product without considering whether that page actually represents a self-service-appropriate decision.
- Inventing a formal threshold rule prematurely — the current informal differentiation hasn't been validated or systematized enough to generalize confidently.

### Confidence
Medium — the gap (no formal prioritization logic) is clearly established; the right resolution requires more product-specific judgment than evidence currently supports.

### Related Research Gaps
- No defined threshold (resource level, price, complexity) for when assisted sales should become the primary path.
- No evidence on whether users encountering the "wrong" primary path (e.g. self-service-primary on a complex product) experience friction.

---

## 5. Let Product Reality Earn Its Own Interaction Pattern

### Principle
Consistency should mean shared foundations, not identical experiences — a product model should diverge from the standard pattern when it genuinely needs to, not by default and not for its own sake.

### Why It Matters
IranServer values a shared UI Kit and unified brand language, and this has real value (cohesion, efficiency, trust). But Cloud Server has already moved partially outside the generic purchase pattern through its configuration-based flow — a case where the product's actual buying model (resource configuration vs. fixed plans) justified a different interaction pattern. This precedent exists without being formalized as a principle.

### Current Evidence
- Cloud Server's configuration experience is a deliberate departure from the standard flow, currently justified by the product's nature (internal product knowledge).
- The configuration is currently simple enough to fit a single form — this reflects current product complexity, not a general rule (internal product knowledge).
- No formal principle currently governs when a product earns a specialized pattern versus reusing the shared structure.

### Design Guidance
- Treat shared components and patterns as the default starting point for any new product page.
- Diverge from the shared pattern only when the product's buying model, complexity, or user needs genuinely don't fit it — as was the case for Cloud Server's configuration flow.
- When complexity grows (e.g. more configuration options in future cloud products), be willing to evolve the interaction pattern (e.g. multi-step, progressive disclosure) rather than forcing continued growth into a single-form structure originally sized for lower complexity.

### Avoid
- Forcing every product into the same generic flow purely for system consistency, when the underlying buying model is fundamentally different.
- Creating bespoke patterns for products that don't actually need them, fragmenting the design system without clear justification.
- Assuming Cloud Server's current single-form pattern will remain adequate as configuration complexity grows.

### Confidence
Medium — the Cloud Server precedent is real and documented; the general principle for *when* to diverge is a reasonable extrapolation, not yet formalized or tested elsewhere.

### Related Research Gaps
- No formal criteria yet for when a product should get a specialized pattern vs. reuse the shared structure.
- Unknown how the current single-form Cloud Server pattern should evolve if configuration complexity increases.

---

## 6. Design Correctly for Today's Billing Model, Without Closing Doors on PAYG

### Principle
Build for the current plan/cycle model as it actually works — but avoid decisions that would make a future usage-based model unnecessarily harder to introduce.

### Why It Matters
Cloud products currently use plan-based, billing-cycle purchasing. PAYG is expected relatively sooner than some of IranServer's other cloud ambitions, but it is not yet an active design requirement. Designing speculative PAYG experiences now would be premature; ignoring the direction entirely risks avoidable rework later.

### Current Evidence
- Current billing model is confirmed as plan + cycle (documented fact).
- PAYG is a stated near-future direction, but not yet implemented or required in current design work (internal product knowledge).
- Current design process prioritizes correctness for the existing model over building around PAYG (current implementation).

### Design Guidance
- Design pricing, configuration, and billing-related UI to be correct and clear for the current plan/cycle model — this is the actual product today.
- Where it doesn't compromise the current experience, favor structural choices (e.g. component architecture, terminology) that wouldn't need to be fundamentally rebuilt if PAYG arrives — without adding speculative complexity to serve a model that doesn't exist yet.
- Do not build PAYG-specific UI, messaging, or flows without confirmed requirements.

### Avoid
- Designing speculative usage-based pricing/cost-estimation UI ahead of actual product requirements.
- Making today's flows deliberately rigid or single-purpose in ways that create unnecessary rework once PAYG requirements are defined.

### Confidence
Strong on "design for today's model"; Exploratory on "how much future-flexibility to build in," since that trade-off hasn't been evaluated case by case.

### Related Research Gaps
- No timeline or requirements yet for PAYG implementation.
- Whether future-facing flexibility should become an explicit design-system or architecture principle is still open.

---

## 7. Layer Content for Business and Technical Readers, Not a Binary

### Principle
Lead with what a less-technical user needs to decide; keep technical depth genuinely accessible, not hidden or absent.

### Why It Matters
IranServer pages are read by both business owners and technical users (developers, designers) — sometimes within the same segment, sometimes across segments (hosting developer vs. cloud developer). Some layering already exists informally (simpler content more visible, technical detail deeper), but it hasn't been systematically designed or validated, and the underlying audience distinctions are still largely hypotheses.

### Current Evidence
- Some content layering already exists in practice (current implementation), but it is informal and not deeply validated.
- Sub-segment technical-sophistication differences (business owner vs. designer vs. developer; hosting developer vs. cloud developer) are documented as working hypotheses, not validated behavior (`users.md`).

### Design Guidance
- Favor progressive disclosure: clear, outcome-oriented framing up front, with technical specificity available for those who want it — continuing and strengthening the existing informal pattern rather than replacing it.
- Avoid assuming a strict binary (business user vs. technical user); design for a spectrum, since even "technical" users differ in what depth they need (e.g. hosting developer vs. cloud developer).
- When in doubt about how much technical depth to expose by default, favor accessible framing first with a clear path to more depth, rather than leading with technical density.

### Avoid
- Assuming the current informal layering is already sufficient or correctly calibrated — it hasn't been validated.
- Treating "business vs. technical" as a fixed persona split that determines entirely separate content paths without evidence that's how users actually behave.

### Confidence
Medium — the general direction (layer, don't binary-split) is reasonable and consistent with current partial practice, but the underlying audience model is still hypothesis-heavy.

### Related Research Gaps
- Whether business-owner vs. developer distinctions (within and across segments) reflect real evaluation behavior.
- Whether current informal content layering is actually effective for either audience.

---

## 8. Keep Promotions Contextual and Subordinate to Trust

### Principle
Promotions can coexist with premium positioning — but only if they stay contextual and don't compete with trust-building for primary attention.

### Why It Matters
Given documented price sensitivity and a premium positioning strategy, aggressive or prominent discounting risks undercutting the value story IranServer is trying to build. Currently, this risk is low: promotions are generally contextual (shown on relevant product/pricing cards) and Hero messaging is not typically discount-led, though campaign periods do temporarily raise promotional emphasis.

### Current Evidence
- Discounts currently appear localized to relevant product/pricing cards, not as dominant Hero messaging (current implementation).
- Campaign/seasonal periods increase promotional emphasis temporarily (current implementation).
- No evidence yet that current promotional practice is actually undermining trust or premium positioning — this is a forward-looking risk to manage, not a documented current problem.

### Design Guidance
- Keep promotional messaging localized and contextual (e.g. on the relevant product/pricing card) rather than elevating it to primary page-level messaging by default.
- During campaigns where promotional emphasis increases, be deliberate about how it's balanced against trust/value signals rather than letting discount messaging dominate by default.
- Frame the underlying design question as "how do promotions coexist with trust and credibility," not "whether promotions should exist."

### Avoid
- Assuming this is currently a live conflict requiring urgent fixing — current practice is already reasonably contained.
- Introducing more prominent or Hero-level discount messaging without considering the premium-positioning tension it could reintroduce.

### Confidence
Strong on current state description; Medium on the forward-looking guidance, since it's a preventive principle rather than a response to a documented problem.

### Related Research Gaps
- Whether campaign-period promotional emphasis has ever measurably affected trust perception or premium positioning.

---

## Decision Checklist

Use this when starting a new website design task:

- **Whose context is this?** Which user/product segment (Hosting & Domain, Cloud, Enterprise) am I actually designing for — and does this page need to serve more than one?
- **Self-service or assisted?** Should this product/page lead with direct purchase, assisted sales, or genuinely support both — and why, for this specific case?
- **Does the generic pattern actually fit?** Is the shared page/component structure appropriate here, or does this product's buying model (like Cloud Server's configuration) justify deviating from it?
- **What's evidence vs. assumption?** Am I building on something documented/validated, or on a working hypothesis that should be labeled and flagged for future validation?
- **Today's product or tomorrow's?** Am I designing for the current business model (plan/cycle billing, current product maturity), or quietly assuming a future state (PAYG, cloud-first) that isn't confirmed yet?
- **Does this add unnecessary system complexity?** If I'm diverging from the shared UI Kit/pattern, is it because the product genuinely requires it — or just because it seemed like a nicer solution?
- **Where does trust sit relative to price/promotion?** If pricing or promotional messaging is involved, is value justification appropriately close by, and is promotional emphasis staying contextual?

---

## Open Research Questions

These are the unresolved questions most likely to materially change these principles if answered:

1. Is current low-visibility cross-sell from Hosting/Domain to Cloud a missed opportunity, or an appropriate reflection of where the business actually is?
2. What is the actual relative weight of price vs. support/trust/uptime in the Hosting & Domain purchase decision?
3. Do users currently perceive IranServer as differentiated by support quality — or is this positioning not yet landing?
4. Is the current Hero-CTA-first structure underperforming for Cloud Products specifically (via CTR, scroll depth, drop-off)?
5. Is the current Hero → Plan Selection → Configuration sequence for Cloud Server optimal, or does it need earlier education?
6. What threshold (resource level, price, complexity) should determine when assisted sales becomes the primary conversion path?
7. How should the Cloud Server configuration pattern evolve — and should it become a reusable pattern for other configurable products — as complexity grows?
8. Do the hypothesized business-vs-technical audience distinctions (within Hosting & Domain, and between Hosting/Domain and Cloud developers) reflect actual user behavior?

---

*This document should be revisited as analytics, user research, and product decisions provide stronger evidence. Confidence levels should be upgraded or downgraded accordingly — principles should never be treated as more certain than their evidence supports.*
