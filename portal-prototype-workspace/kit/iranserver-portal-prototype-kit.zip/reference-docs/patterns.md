# IranServer Website — Patterns

This document records recurring UX/page patterns observed so far on the IranServer website. It is based on **two Product Landing Pages (PDPs) only**: the WordPress Hosting PDP and the Germany VPS (Cloud Server) PDP. It does not yet incorporate Pillar Page patterns, other Hosting products, other Cloud products, or Enterprise pages.

**Sample-size caution**: every pattern below is derived from exactly one Hosting example and one Cloud example. Where a pattern looks consistent across both, that should be read as "consistent in these two instances," not "confirmed sitewide." Where a pattern differs, that difference could reflect an intentional product-specific decision, an unintentional inconsistency, or simply which sections a given page happened to include — we generally cannot tell which from two data points, and this is flagged per pattern rather than resolved.

---

## Hero + Primary CTA

### Purpose
Orient the user to the specific product and offer an immediate path toward conversion.

### Used In
Both Hosting PDP and Cloud PDP (top of page, first section).

### Current Structure
Product title, short subtitle, and CTA button(s) leading toward the plan-selection section below.

### Variations
Hosting PDP uses a single Hero CTA. Cloud PDP uses two Hero CTAs side by side. The destinations of the Cloud PDP's two CTAs were not distinguishable from the screenshot.

### Evidence
Existing design convention (both pages clearly use a Hero pattern); the single-vs-dual CTA difference has no documented rationale — **Unknown / legacy reason**.

### Design-System Relationship
Likely a shared Hero section template (title + subtitle + CTA slot), with the CTA slot apparently supporting either one or two buttons — whether that's a deliberate configurable option or two different implementations is not determinable from screenshots alone.

### Status
Established shared pattern (structurally), with an unresolved variation in CTA count.

### Notes
Worth checking whether the dual-CTA Hero appears on other Cloud products or is specific to Germany VPS, and whether it's a deliberate "self-serve vs. learn more" split.

---

## Product Introduction

### Purpose
Establish, in plain terms, what this specific product is and who it's for, before asking the user to evaluate plans.

### Used In
Both PDPs, expressed through the Hero subtitle and, more substantially, through value/positioning content later in the page (e.g. Cloud PDP's "best choice for..." bullet block).

### Current Structure
Short framing text near the top; fuller positioning statements appear again lower on the page, interleaved with feature and trust content rather than concentrated in one place.

### Variations
Hosting PDP's introductory framing is comparatively brief and quickly gives way to plan selection. Cloud PDP repeats and reinforces product framing at multiple points (Hero, advantages grid CTA, later positioning block) — introduction is more distributed.

### Evidence
Existing design convention, but the degree of repetition looks like it may be a **product-specific requirement** — consistent with the (unvalidated) hypothesis in `users.md` that Cloud users need more context before deciding. This is speculative, not confirmed.

### Design-System Relationship
No single dedicated "introduction" component is evident; this content appears to ride along within Hero and value-block sections rather than being its own reusable structure.

### Status
Needs further investigation.

### Notes
Cannot confirm from two pages whether Cloud's more distributed introduction reflects a deliberate response to the education-first hypothesis, or is incidental to this specific product's content.

---

## Plan Selection Entry

### Purpose
Let the user choose a specific purchasable tier/configuration of the product.

### Used In
Both PDPs, immediately following the Hero.

### Current Structure
A grid of cards (5–6 per page), each showing a plan name, price, a checklist of included features/specs, and a CTA button. Plan selection is placed early in the page — before most educational or trust content — on both pages.

### Variations
Hosting PDP's plan cards emphasize feature checkmarks. Cloud PDP's plan cards emphasize concrete technical resources (RAM/CPU/disk/bandwidth implied by the checklist) and include a grouping toggle above the grid, not present on the Hosting PDP.

### Evidence
Existing design convention for the card grid itself; the content schema difference (features vs. resource specs) is a **product-specific requirement** — hosting plans are commonly differentiated by feature bundles, VPS plans by raw resources.

### Design-System Relationship
Strong candidate for a shared, reusable plan-card component (consistent shape: title, price, checklist, CTA) used with different underlying data across product types. The Cloud-only grouping toggle may be an optional element of the same component, or a separate addition — not determinable from screenshots.

### Status
Established shared pattern (structure), with a confirmed content-schema variation between Hosting and Cloud.

### Notes
This is one of the stronger candidates for a genuinely reusable pattern seen so far, since the underlying shape repeats despite very different content.

---

## Pricing Presentation

### Purpose
Give the user cost information early enough to support a quick self-service decision.

### Used In
Both PDPs — pricing appears directly on each plan card, immediately visible without requiring further navigation.

### Current Structure
Price displayed prominently within each plan card, alongside the plan's feature/spec checklist.

### Variations
No major structural variation observed. Hosting PDP additionally included an urgency/countdown promotional banner near the plan grid; Cloud PDP did not.

### Evidence
Business requirement — early price visibility is consistent with the price-sensitivity tension already documented for Hosting & Domain users in `users.md`, though we cannot confirm this same rationale drives Cloud's identical placement.

### Design-System Relationship
Pricing appears to be a built-in field within the shared plan-card component described above, rather than a separate pattern.

### Status
Established shared pattern.

### Notes
The urgency/countdown banner's absence on Cloud is worth tracking as a possible Hosting-specific promotional pattern (see Product-Specific Patterns below).

---

## Feature / Benefit Communication

### Purpose
Communicate the product's value beyond price and raw specs.

### Used In
Both PDPs, in multiple sections each.

### Current Structure
Hosting PDP: a shared-features strip plus three longer-form paragraph "deep-dive" blocks (storage, support, security).
Cloud PDP: a shared-features strip, three shorter icon-based feature cards, and a separate six-item advantages icon grid.

### Variations
Cloud PDP splits this job across more, smaller, more visually segmented sections; Hosting PDP concentrates it into fewer, denser, more text-heavy blocks.

### Evidence
Existing design convention for the general approach (features communicated via icon/text blocks); the difference in segmentation and depth has no documented rationale — **Unknown / legacy reason**.

### Design-System Relationship
Likely draws on a shared "feature card" or "icon + label + description" component, reused with different quantities and groupings per page rather than a fixed template.

### Status
Inconsistent pattern.

### Notes
Same underlying goal, meaningfully different execution. Worth checking whether this reflects a deliberate content-density decision (e.g. Cloud content intentionally kept scannable) or just how each page happened to be built.

---

## Technical Specification

### Purpose
Communicate concrete technical/hardware capability to build technical credibility and inform the decision.

### Used In
Hosting PDP only, in the two PDPs reviewed — a dedicated technical specs table and a separate technical-benchmark block (RAID10/NVMe performance bars). Cloud PDP has no equivalent dedicated section; technical specs appear only inline within the plan cards themselves (RAM/CPU/disk in the checklist).

### Current Structure
Hosting: standalone specs table plus a visually distinct performance-benchmark block with comparative bar charts.
Cloud: no standalone section — specs are folded into plan selection.

### Variations
Significant. This is one of the clearest structural differences found between the two pages.

### Evidence
Unknown / legacy reason — no documentation confirms whether Cloud deliberately omits a dedicated technical section (e.g. because specs are self-evident from the plan cards) or simply hasn't had one built yet.

### Design-System Relationship
Hosting's specs table and benchmark block did not show an obvious equivalent structure on the Cloud PDP, suggesting these may be page-specific or Hosting-specific compositions rather than shared components — not confirmed.

### Status
Inconsistent pattern.

### Notes
Worth flagging clearly: this could be a genuine gap (Cloud users being an audience `users.md` hypothesizes as more technically sophisticated might expect more technical detail, not less) or could reflect that resource specs on the plan cards already serve this purpose for VPS. This should not be resolved without more evidence.

---

## Trust / Credibility

### Purpose
Reduce perceived purchase risk and build confidence in IranServer as a provider.

### Used In
Both PDPs, extensively and in multiple forms.

### Current Structure
A recurring dark "why choose us" value block (different content per page), a stats bar (years in business, customers served, etc.), a client logo strip, and testimonials — generally positioned in the lower half of the page on both.

### Variations
Minimal structural variation; content differs by product as expected. The dark value-block pattern has now been observed with different content across multiple pages in this audit process, reinforcing its likely status as a shared, swappable-content template.

### Evidence
Existing design convention, and plausibly a **business requirement** — consistent with the premium-positioning-vs-price-sensitivity tension documented in `design-principles.md`, where trust signals are expected to carry weight in the purchase decision. Not confirmed as intentionally placed for that reason.

### Design-System Relationship
Strong candidate for several shared components: a dark value-block template, a stats-bar component, a logo-strip component, and a testimonial-carousel component.

### Status
Established shared pattern.

### Notes
This is the most consistently repeated pattern type across both pages.

---

## Contact Sales / Consultation

### Purpose
Offer an assisted path for users who are not ready or able to self-serve a purchase decision.

### Used In
Cloud PDP only, in the two PDPs reviewed — an inline contact/inquiry form (name, email, message) roughly two-thirds down the page. The Hosting PDP (WordPress) has **no visible assisted-path mechanism at all**; the only consultation-style block observed in this audit appeared on the Hosting *Pillar* page, not this specific product page.

### Current Structure
Cloud: an embedded form directly in the page, with contact info (phone/email) alongside it.
Hosting PDP: none observed.

### Variations
This is a notable gap rather than a stylistic variation — one PDP offers an assisted path, the other does not.

### Evidence
Unknown / legacy reason.

### Design-System Relationship
Cannot determine if the Cloud PDP's form is a shared "contact form" component potentially available (but unused) on the Hosting PDP, or a Cloud-specific addition.

### Status
Inconsistent pattern.

### Notes
This directly touches the path-prioritization tension already flagged in `design-principles.md` (Principle 4) — there is still no evidence-based rule for when an assisted path should appear, and its presence/absence here looks more like a per-page inclusion decision than a deliberate product-complexity-based rule.

---

## FAQ

### Purpose
Address common pre-purchase questions and objections.

### Used In
Both PDPs, positioned in the lower-middle portion of the page in both cases.

### Current Structure
Accordion-style list of expandable questions, product-specific content.

### Variations
Format is consistent; only content differs, as expected.

### Evidence
Existing design convention.

### Design-System Relationship
Strong candidate for a shared, reusable accordion component.

### Status
Established shared pattern.

### Notes
None significant — this is one of the more confidently reusable patterns observed.

---

## Related Products / Cross-sell

### Purpose
Surface adjacent products, add-ons, or content the user might also need.

### Used In
Cloud PDP has an explicit "related products and services" tabbed section (security, license, VIP support, etc.) — a true product/add-on cross-sell. Hosting PDP instead has a "latest from the blog" content block — a content cross-link, not a product cross-sell. No product-level cross-sell (e.g. to other hosting types or to Cloud) was observed on the Hosting PDP.

### Current Structure
Cloud: tabbed add-on selector.
Hosting: blog article cards.

### Variations
These solve different problems despite both sitting in a similar page position — one is commercial cross-sell, the other is content engagement. Not confirmed as an intentional differentiation.

### Evidence
Unknown / legacy reason.

### Design-System Relationship
No shared component evident between the two — they appear to be genuinely different section types occupying a similar page slot.

### Status
Inconsistent pattern.

### Notes
Worth noting this sits alongside the already-documented finding in `users.md` that cross-sell (specifically Hosting→Cloud) is currently low-priority and low-visibility — this pattern-level finding is a related but distinct observation, since it's about product cross-sell generally, not specifically the Hosting-to-Cloud direction.

---

## Educational Content

### Purpose
Help users understand the product or category deeply enough to decide confidently, and likely support SEO.

### Used In
Both PDPs, though structured differently.

### Current Structure
Hosting PDP: education is distributed through three feature deep-dive paragraph blocks earlier in the page.
Cloud PDP: education is consolidated into one long, structured "buying guide" article with named subsections, positioned near the bottom of the page (after FAQ).

### Variations
Different placement (distributed vs. consolidated) and different position relative to FAQ (before vs. after).

### Evidence
Existing design convention combined with a likely **business requirement** (SEO content value) — not confirmed.

### Design-System Relationship
No single shared "educational content" component is evident; both instances read as freeform content blocks rather than a structured, reusable pattern.

### Status
Candidate for standardization — the underlying need (deeper education) is shared, but the execution differs enough that it's unclear if this is one pattern or two.

### Notes
Given `users.md`'s hypothesis that Cloud users need more education before deciding, it's notable that Cloud's educational content is positioned *after* the FAQ and most conversion opportunities, not before — this placement question is worth investigating rather than assuming it's already solved correctly.

---

## Configuration Entry

### Purpose (intended)
Allow users to customize technical parameters (e.g. operating system, additional resources) beyond the plan tier, before completing a purchase.

### Used In
**Not observed on either PDP reviewed.** No configuration step was visible after plan selection on either page — what happens after a plan CTA is clicked (direct checkout vs. a configuration step) is outside what either screenshot captured.

### Current Structure
Unknown.

### Variations
Unknown.

### Evidence
Unknown / legacy reason — this is a gap in our evidence, not a confirmed absence of the feature. Earlier documentation (prior to this PDP audit) described a "Plan Selection → Configuration" step for Cloud Server, but nothing in the two PDPs reviewed confirms or shows this step directly.

### Design-System Relationship
Unknown.

### Status
Needs further investigation.

### Notes
This is the single most important open gap from this audit. Confirming what happens post-plan-selection is necessary before any pattern documentation about configuration can be considered reliable.

---

## Shared Patterns Across Hosting and Cloud

Patterns judged genuinely reusable across both product types, based on consistent structure despite differing content:

- **Hero + Primary CTA** (structure shared; CTA count varies — see notes above)
- **Plan Selection Entry** (strong candidate — consistent card-grid shape with different data schemas)
- **Pricing Presentation** (consistent placement and prominence)
- **Trust / Credibility** (dark value block, stats bar, logo strip, testimonials — most consistently repeated pattern type)
- **FAQ** (consistent accordion format)

## Product-Specific Patterns

### Hosting-Specific (observed on Hosting PDP, not on Cloud PDP)
- Dedicated technical specifications table
- Technical performance-benchmark block with comparative bar charts
- Urgency/countdown promotional banner
- Competitive bandwidth/performance comparison bars
- Blog-article cross-link block (content cross-sell, in place of a product cross-sell)

### Cloud-Specific (observed on Cloud PDP, not on Hosting PDP)
- Dual Hero CTA
- Inline contact/inquiry form as the assisted-path mechanism
- Resource-spec-driven plan cards with a grouping toggle
- Explicit "related products and services" tabbed cross-sell
- Long-form structured buying guide positioned after FAQ

---

*This document reflects two PDP examples only. Every "Inconsistent pattern" and "Needs further investigation" status above should be re-evaluated as more Hosting and Cloud pages — and the still-missing post-plan-selection/configuration flow — are reviewed. Do not treat any pattern here as sitewide-confirmed from this evidence alone.*
