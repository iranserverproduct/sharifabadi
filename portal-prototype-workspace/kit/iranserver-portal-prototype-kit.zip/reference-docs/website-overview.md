# IranServer Website Overview

## 1. Product Overview

IranServer is an infrastructure and web-services provider that originally entered the market through **web hosting and domain registration**.

Historically, hosting and domain services have formed a significant part of IranServer's customer base and website traffic.

Over time, IranServer has expanded its portfolio into cloud and infrastructure services, including products such as:

* Cloud Servers
* Object Storage
* Block Storage
* CDN and related infrastructure services

IranServer's long-term strategic direction is to increase its focus on **cloud infrastructure and cloud-based products**, while hosting and domain services remain important parts of the current business.

The brand slogan commonly used across brand and social channels is:

**"خانه امن رویاهای شما"**
*"A safe home for your dreams."*

---

## 2. Website Role

The website's primary role is **direct sales and customer acquisition**.

Most current commercial traffic and purchasing activity is still associated with hosting and domain services.

The website should help users:

* Understand their needs
* Discover relevant products and services
* Compare available solutions
* Build confidence and trust before purchasing
* Make a direct purchase whenever possible

As IranServer's product portfolio evolves, the website should gradually support stronger discovery, education, and conversion for cloud products.

### Strategic Direction

Current focus:

**Hosting + Domain + Infrastructure Services**

Long-term direction:

**Stronger Cloud Infrastructure and Cloud Products positioning**

The website should support this transition without presenting IranServer as a fully cloud-native platform before the product portfolio and experience support that positioning.

---

## 3. Primary User Segments

### Hosting and Domain

Primary users include:

* Business owners
* Web designers
* Web developers

These users commonly visit the website to launch, host, or maintain websites and digital businesses.

### Cloud Products

Primary users include:

* Developers
* Small businesses
* Growing digital businesses

These users generally have more technical infrastructure needs and may require services such as compute, storage, scalability, or related cloud infrastructure.

### Enterprise and Large Organizations

IranServer also provides infrastructure services to larger companies and organizations.

This segment behaves differently from standard website customers.

Enterprise deals are often:

* High-value
* More complex
* Consultation-driven
* Completed through direct negotiation with sales or account teams

Therefore, the website's role for enterprise users is often **lead generation, credibility building, and solution discovery**, rather than fully automated self-service purchasing.

Only a limited number of website pages currently specifically target this segment.

---

## 4. Website vs. Portal

The Website and Portal serve fundamentally different stages of the customer journey.

### Website

Primary purpose:

**Discover → Understand → Evaluate → Purchase**

The website should:

* Explain user needs
* Introduce products and services
* Communicate value
* Reduce purchase uncertainty
* Build trust
* Help users select the right solution
* Encourage conversion

### Portal

Primary purpose:

**Manage purchased services**

The Portal is used after purchase and focuses on service management.

Its structure is partially influenced by WHMCS and the technical lifecycle of infrastructure services.

Typical primary actions include:

* Service renewal
* Service upgrade
* Service management
* Configuration
* Reviewing service status and resources

Therefore, Website design should generally prioritize **discovery and decision-making**, while Portal design should prioritize **management efficiency and operational actions**.

---

## 5. Design Context

When designing IranServer's website, decisions should consider both:

### Current Business Reality

Hosting and domain services remain major sources of traffic, customers, and direct online purchases.

### Future Business Direction

IranServer intends to strengthen its position in cloud infrastructure and expand the role of cloud products within its business.

Design decisions should support this transition progressively rather than forcing a cloud-only positioning onto the current customer base.

---

## 6. Core Website Objectives

In order of general importance:

1. Drive qualified direct purchases.
2. Help users identify the right product for their needs.
3. Reduce uncertainty before purchase.
4. Build trust in IranServer as an infrastructure provider.
5. Educate users about more complex services.
6. Increase awareness and adoption of cloud products.
7. Generate qualified leads for enterprise and high-complexity infrastructure needs.
