# Figma context — IranServer (Portal / Uikit V3)

- Portal file key: `1qrZx6L5Ug2eniRA8epD2U`, page "Domain" (id 19242:17272). Libraries: "Portal", "Uikit V3". Font: Peyda.
- Uikit-V3 file: Section Library on the Section page (node 10947:1457).
- Domain Transfer redesign frames (page Domain, below label 38976:20113): Desktop Other `39016:20317`, Desktop IR `39019:20998`, Tablet `39019:21224`, Tablet IR `39019:22034`, Mobile `39019:21342`, Mobile IR `39019:21756`.
  (Keys/IDs belong to the old account's file access; the new account needs access to the same Figma file.)

## Rules learned
- Auto-layout has no RTL: list children in visual left→right order; Persian text alignment RIGHT.
- Bind colors/text to Uikit V3 variables & styles; import by key; componentize repeats.
- Shell: Header instance (Side=Dashboard, Device=Desktop/Tablet/Mobile) + Body (padding D [24,240,32,240], T [24,40,32,40], M [12,16,24,16]; fill Surface Container) + white card (radius 8, pad 32/24/16).
- Components used: Input (Type=Default; props Show Description etc.), Button (Type/Status/State; Title prop), Checkbox, Alert (Type=Info, Device), Radio Card (State; props Show Logo/Dropdown/Tag...), Breadcrumb Cell, Header, Tag.
- Radio Card was built for OS selection — logo/dropdown turned off for domain type.

## Update 2026-11-04
Website file key `LuqQNLxinLogoKEgOCTwyr` (page VPS `13554:56421`) and Uikit-V3 `0uxzan8L6i5bMtqwdjjOlX` — see `02-CURRENT-STATE.md` for all node IDs.
