# IranServer Website — Users

This document consolidates current knowledge about IranServer's primary website user segments. It combines documented facts, internal product knowledge, and working hypotheses — each explicitly labeled. It is a living document and should be updated as new evidence becomes available.

---

## 1. Hosting & Domain

### Segment Definition
Business owners, web designers, and web developers who use the website to launch, host, or maintain websites and digital businesses.
*Evidence level: Documented fact*

### Primary Intent
The dominant intent is new purchase — typically for a new website or project. IranServer's current marketing and promotional offers are also focused on acquiring new customers rather than migration/renewal scenarios. Migration, renewal, or expansion use cases exist but are not the current focus of the website or marketing strategy.
*Evidence level: Internal product knowledge*

### Technical Sophistication
Working hypothesis on sub-segment differences:
- Developers may care more about technical specifications, infrastructure details, and technical capabilities.
- Web designers may have somewhat lower technical depth than developers, while still understanding hosting-related concepts.
- Business owners may focus more on service outcomes (reliability, uptime, stability, ability to handle heavier usage) than low-level technical specs.

*Evidence level: Working hypothesis — not yet validated through research, analytics, or support/sales feedback.*

### Purchase / Evaluation Criteria
A prior hosting-related questionnaire identified price as one of the main concerns for most users.
*Evidence level: Internal product knowledge (questionnaire-based)*

There is a notable tension: despite documented price sensitivity, IranServer's business/brand strategy for this segment is closer to premium positioning — selling fewer services at a higher price, avoiding competition on low price/volume, and positioning support quality as a key differentiator.
*Evidence level: Internal product knowledge (business strategy)*

The relative importance of price versus support, uptime, performance, and brand trust has not been validated beyond the price-sensitivity finding.
*Evidence level: Open question*

### Purchase Model
Primarily self-service, with support involvement in specific operational or technical cases: users browse, choose a plan, complete purchase, and manage the service without direct sales assistance in most cases. Support/tickets are used for specific operational or technical needs (e.g. SSL activation in some cases), with an ongoing effort to fold such cases into self-service to reduce support dependency.
*Evidence level: Internal product knowledge*

### Current Website Role
Direct, primarily self-service sales channel, with support involvement in specific operational or technical cases, for the segment that currently represents a major share of IranServer's traffic and purchase activity.
*Evidence level: Documented fact / internal product knowledge*

### Strategic Direction
No major shift documented; this segment remains the current core business while IranServer's broader strategic focus shifts toward cloud. Continued effort to reduce support dependency by expanding self-service coverage (e.g. SSL activation).
*Evidence level: Internal product knowledge*

### Open Questions
- How do developers, designers, and business owners actually differ in evaluation behavior (currently only a hypothesis)?
- What is the relative weight of price vs. support/uptime/trust in the actual purchase decision?
- Is there a specific point in the pre-purchase journey where users hesitate or drop off? (No validated evidence yet — explicitly flagged as unknown, not to be treated as a design assumption.)

---

## 2. Cloud Products

### Segment Definition
Developers, small businesses, and growing digital businesses with more technical infrastructure needs — compute, storage, scalability, and related cloud infrastructure.
*Evidence level: Documented fact*

### Primary Intent
Current working assumption: users arriving on cloud product pages generally have some prior understanding of the product category but still need education before deciding — specifically on what the product does, where it fits, what use cases it supports, why they may need it, and how IranServer's offering differs or adds value. As a result, cloud landing pages are currently designed around a mix of education, evaluation, and conversion rather than sales-only messaging.
*Evidence level: Working hypothesis / design assumption — not validated through formal research.*

### Technical Sophistication
Working hypothesis: the Cloud Products developer audience is generally more technically sophisticated and infrastructure-oriented than the developer audience purchasing traditional hosting — more likely to understand compute, storage, scalability, deployment, and system configuration concepts, versus a hosting developer more focused on website/application deployment.
*Evidence level: Working hypothesis — not yet validated.*

### Purchase / Evaluation Criteria
No validated data on which criteria matter most to cloud users. Current product approach for Cloud Server follows a configuration-based purchasing model (similar to competitor patterns), giving significant weight to resource transparency and configuration control (compute, memory, storage, etc.). This reflects a product/design approach based on market pattern and assumption, not validated evidence of user preference. Other factors (pricing, performance, support, scalability, location, provisioning experience) may also matter and remain unvalidated.
*Evidence level: Internal product knowledge (design approach) — underlying user preference is an open question.*

### Purchase Model
Transitioning toward greater self-service and automation. The current Cloud Server purchase experience already includes a configuration page (datacenter, operating system, compute resources, and other parameters) that reduces dependency on manual sales/support involvement. This transition is ongoing — not all cloud products or operational steps should be assumed fully automated yet.
*Evidence level: Internal product knowledge*

Billing model: currently plan-based with a billing cycle, not usage-based. Strategic direction is toward Pay-As-You-Go (PAYG), but this has not yet been implemented. Current design should reflect the existing plan/cycle model without implying a fully usage-based platform, while avoiding architectural choices that would make a future PAYG transition harder.
*Evidence level: Internal product knowledge (current state and stated strategic direction)*

### Current Website Role
Mixed education, evaluation, and conversion channel — more self-service than in the past, but still assumes users need context and justification before purchasing, unlike hosting/domain's more transactional model.
*Evidence level: Internal product knowledge*

### Strategic Direction
Continued movement toward self-service and automation across more cloud products. Long-term move from plan-based billing toward PAYG (not yet implemented). Whether the Hosting & Domain premium-pricing strategy also applies to Cloud Products is unconfirmed.
*Evidence level: Internal product knowledge (direction) / Open question (pricing strategy applicability)*

### Competitive Context
Primary direct competitive benchmark: ArvanCloud (referenced in roughly 90% of competitive comparisons). Occasional references: DigitalOcean, OVH. AWS is not generally used as a direct benchmark. Broader cloud-industry patterns (scalability, flexible resource allocation, configuration-based purchasing, self-service provisioning) are considered when relevant.
*Evidence level: Internal product knowledge*

### Open Questions
- Is the education-first landing page assumption actually matched by user behavior, or do some users arrive ready to convert immediately?
- How technically sophisticated is the cloud developer audience relative to the hosting developer audience, in practice?
- Which purchase criteria (price, performance, support, location, provisioning ease) actually matter most to cloud buyers?
- Does the Hosting & Domain premium-pricing strategy extend to Cloud Products?

---

## 3. Enterprise / Large Organizations

### Segment Definition
Larger companies and organizations with high-value, complex, consultation-driven infrastructure needs, typically completed through direct negotiation with sales or account teams.
*Evidence level: Documented fact*

### Primary Intent
No validated data on how enterprise prospects discover or evaluate IranServer. Working hypothesis: large enterprise opportunities are primarily driven through direct sales relationships and human-assisted channels rather than a fully website-led journey; the website plays a supporting role in credibility and interest capture. Smaller organizations with more standardized needs (e.g. a dedicated server) may be able to evaluate and purchase through a more conventional website journey.
*Evidence level: Working hypothesis*

### Technical Sophistication
Not documented or hypothesized in detail. No claims should be made here beyond what is stated elsewhere (complex, consultation-driven needs).
*Evidence level: Open question*

### Purchase / Evaluation Criteria
No validated data on what drives enterprise decisions. Datacenter location has historically been relevant in some cases but should not be treated as a universal or primary current driver without further evidence. Infrastructure capability and capacity are hypothesized to matter for larger/critical workloads. Other possible factors — SLA, dedicated support, security, custom infrastructure, pricing, account management, compliance, existing relationships — are unvalidated and remain open questions.
*Evidence level: Working hypothesis (capability/capacity, datacenter location) / Open question (all other factors)*

### Purchase Model
Primarily sales-assisted for large enterprise / complex infrastructure needs. Smaller organizations with standardized needs may be more self-service. Current working model:
- Large enterprise / complex needs → primarily sales-assisted
- Smaller organizations / standardized needs → potentially more self-service

*Evidence level: Working hypothesis*

### Current Website Role
The website already has several enterprise-related touchpoints: a dedicated enterprise sales page, dedicated pages for some enterprise-scale services, and a prominent business-focused section on the homepage. Enterprise engagement is not happening entirely outside the website. However, the experience is currently fragmented — there is no clearly structured, end-to-end journey connecting enterprise positioning → relevant solutions → credibility → lead capture → sales contact. The site currently functions as multiple enterprise entry points without a consolidated enterprise information architecture or conversion strategy.
*Evidence level: Documented / internal product knowledge*

### Strategic Direction
IranServer's strategic direction is toward stronger cloud infrastructure and larger-scale capability. However, current commercial concentration is more toward smaller to mid-sized businesses and lower-resource requirements. Enterprise customers should not be assumed to simply buy the same Cloud Products at larger scale — this relationship is unconfirmed.
*Evidence level: Internal product knowledge (strategic direction) / Open question (Enterprise–Cloud Products relationship)*

### Open Questions
- How do enterprise prospects actually discover and evaluate IranServer?
- What factors most strongly drive enterprise purchase decisions?
- Why do enterprise deals rely more heavily on direct sales — customization needs, contract value/negotiation, need for account management, or current self-service/pricing model limitations? (Several possible explanations exist; none validated.)
- Does the Enterprise segment overlap with Cloud Products in practice, or are they functionally distinct audiences/products?
- What would a consolidated, end-to-end enterprise journey need to look like, given the current fragmented touchpoints?

---

## Cross-Segment Design Implications

These are observations about differences that *could* affect design decisions — not yet fixed rules.

- **Content depth**: Hosting & Domain appears to support more transactional, lower-friction content; Cloud Products currently assumes a need for more explanatory/educational content before conversion; Enterprise may need the deepest credibility-building content (case studies, capability proof) before a lead is even captured, though this is a working implication rather than an established design fact.
- **Technical language**: Hosting & Domain may need to flex between simplified (business owner) and technical (developer) language within the same segment. Cloud Products may support more technical language by default, per the (unvalidated) hypothesis of a more infrastructure-sophisticated audience. Enterprise language needs are currently undocumented.
- **Conversion model**: Hosting & Domain is primarily self-service, with support involvement in specific operational or technical cases. Cloud Products is transitioning toward self-service but not fully there. Enterprise is presumed sales-assisted for larger/complex needs, with smaller organizations potentially closer to self-service — this split is itself only a hypothesis.
- **CTA strategy**: Hosting & Domain likely supports direct "buy now" CTAs. Cloud Products may need CTAs that account for an education-then-convert path. Enterprise may be better served by lead-generation CTAs such as contact sales or request consultation rather than purchase CTAs, but this remains a working implication that should be validated — and the current experience achieves this only fragmentedly across multiple entry points.
- **Pricing presentation**: Hosting & Domain has a documented price-sensitivity vs. premium-positioning tension that pricing presentation may need to actively address. Cloud Products uses configuration-based pricing (resource-driven, not fixed packages) and is billed on a plan/cycle basis while heading toward PAYG — pricing UI should not assume a stable, purely fixed-package or purely usage-based model. Enterprise pricing may require assisted or negotiated presentation rather than assuming a standard fixed-price model.
- **Trust and credibility**: Hosting & Domain's premium positioning suggests trust signals (support quality, reliability) may need more visible emphasis given known price sensitivity. Enterprise trust needs are presumed to be the highest-stakes (SLAs, credibility, capability proof) but are currently undocumented in detail.
- **Self-service vs. assisted journeys**: The three segments currently sit at different points on this spectrum — Hosting & Domain (primarily self-service, with support involvement in specific operational or technical cases), Cloud Products (transitioning), Enterprise (presumed assisted, with a possible self-service subset for smaller/standardized needs). This spectrum itself may be a useful organizing framework for future IA decisions, but should not be treated as settled until validated.

---

## Research Gaps (Highest Priority)

1. Validate the hypothesized technical-sophistication differences within Hosting & Domain (business owner vs. designer vs. developer) and between Hosting/Domain developers and Cloud Products developers.
2. Identify actual weight of decision criteria for Hosting & Domain (price vs. support/uptime/trust) and for Cloud Products (configuration/resources vs. price/performance/support/location).
3. Determine whether a specific friction or drop-off point exists in the Hosting & Domain pre-purchase journey (via funnel analysis, support ticket themes, or usability testing).
4. Validate whether the education-first assumption for Cloud Products landing pages matches actual user behavior.
5. Determine how enterprise prospects currently discover and evaluate IranServer, and what most strongly drives their purchase decisions.
6. Clarify the reason(s) enterprise deals rely on direct sales — custom requirements, contract complexity, account management needs, or current self-service/pricing model limitations.
7. Clarify the actual relationship (overlap or distinction) between the Enterprise and Cloud Products segments.
8. Confirm whether IranServer's premium-pricing strategy for Hosting & Domain applies to Cloud Products.

---

*Last updated from internal product knowledge session, structured jointly with the IranServer product designer. All hypotheses and open questions above should be revisited as validated evidence becomes available.*
