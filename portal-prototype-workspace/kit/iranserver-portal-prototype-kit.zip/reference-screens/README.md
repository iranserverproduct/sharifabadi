Reference renders from the Portal Figma file (2026-11-08):
- portal-service-list-table-desktop.png  — `Cloud Services - Table` 36875:166787
- portal-purchase-wizard-config-desktop.png — `Service configuration` 12533:26612 (stepper + radio-card periods + footer buttons)
- portal-block-storage-table-mobile.png — `Block Storage - Table (Mobile)` 36933:6920
- portal-login-desktop.png — `login` 13730:14668
- html-starter-*.png — how the HTML starter (prototype-starter/) renders the same patterns (system font fallback instead of Peyda).
