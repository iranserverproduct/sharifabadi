# Tokens (Uikit-V3 variables)

Machine-readable: `tokens.json` (primitives, semantic→primitive map, spacing, radius, stroke, typography, layout) and `../prototype-starter/tokens.css`.

Rule: in Figma **bind** to the semantic variable name below (collection *Semantic Tokens*); never to a primitive or raw hex.

## Semantic colours (name → hex)

| Variable | Hex |
|---|---|
| `Primary/Primary` | #2635d9 |
| `Primary/On Primary` | #ffffff |
| `Primary/Primary Container` | #f2f7fd |
| `Primary/Primary Container Variant 1` | #dcebf9 |
| `Primary/On Primary Variant 2` | #172082 |
| `Primary/On Primary Variant 3` | #0f1557 |
| `Primary/On Primary Variant 4` | #01041f |
| `Primary/On Primary Variant 5` | #1f2aad |
| `Secondary/Secondary` | #fa8100 |
| `Secondary/On Secondary` | #ffffff |
| `Secondary/Secondary Container` | #fff3e5 |
| `Secondary/On Secondary Container` | #331a00 |
| `Secondary/Secondary Container Variant 1` | #ffe6cc |
| `Tertiary/Tertiary` | #14b855 |
| `Tertiary/On Tertiary` | #ffffff |
| `Tertiary/Tertiary Container` | #e8fcf0 |
| `Tertiary/On Tertiary Container` | #052e15 |
| `Tertiary/Tertiary Variant 1` | #0f8a41 |
| `Surface/Surface` | #fafafa |
| `Surface/On Surface` | #323234 |
| `Surface/Surface Container` | #f4f4f5 |
| `Surface/On Surface Variant 1` | #e4e5e7 |
| `Surface/On Surface Variant 2` | #95969d |
| `Surface/On Surface Variant 3` | #cacace |
| `Surface/On Surface Variant 4` | #62636a |
| `Surface/Surface Bright` | #ffffff |
| `Surface/Surface Dark` | #000000 |
| `Outline/Outline` | #e4e5e7 |
| `Outline/Outline Varient` | #cacace |
| `Outline/Outline Varient 2` | #f4f4f5 |
| `Success/Success` | #d8f3e3 |
| `Success/Success Container` | #1e7b22 |
| `Success/On Success` | #173f03 |
| `Error/Error` | #fbe5e4 |
| `Error/Error Container` | #b01111 |
| `Error/On Error` | #520400 |
| `Warning/Warning` | #fff8e0 |
| `Warning/Waning Container` | #f7a709 |
| `Warning/On Warning` | #422d03 |
| `Info/Info` | #d3e6f8 |
| `Info/Info Container` | #0e94f9 |
| `Info/On Info` | #073254 |
| `Docs/Docs` | #3d1e7b |
| `Docs/Docs Container` | #e1d8f3 |
| `Docs/On Docs` | #240464 |
| `Disable/Disable` | #f4f4f5 |
| `Disable/On Disable` | #7a7b85 |
| `Disable/Disable Container` | #e4e5e7 |
| `Disable/Disable Outline` | #e4e5e7 |
| `Pure Color/Pure White` | #ffffff |
| `Pure Color/Pure Black` | #000000 |

Also exist (not listed): Pastel Palette/* (Turquoise, Orange, Green, Ocean Blue, Red, Yellow, Sky Blue, Dark Blue, Purple, Dirty Yellow, Pink — each with `X` and `X Container`) used for category colouring. Brand: **Primary #2635d9** (logo blue), **Secondary #fa8100** (logo orange).

## Spacing (Gap/*)
`Gap/None=0`, `Gap/05=2`, `Gap/1=4`, `Gap/2=8`, `Gap/3=12`, `Gap/4=16`, `Gap/5=20`, `Gap/6=24`, `Gap/8=32`, `Gap/10=40`, `Gap/14=56`, `Gap/16=64`, `Gap/20=80`, `Gap/22=88`, `Gap/30=120`, `Gap/35=140`, `Gap/Margin For Grid=300`

## Radius / Stroke
Radius: None=0, Small=4, Medium=8, Large=12, X-Large=40, Curve=120. Stroke: None=0, Small=1, Medium=1.5, Large=2.

## Layout
- **Portal**: widths 1920/842/390 · content max 1440 · header 68 · body padding D[24,240,32,240] T[24,40,32,40] M[12,16,24,16] · card radius 8 padding 24.
- **Website sections**: widths 1920/744/360 · section padding D[88,300] T[40,32] M[32,16].

## Typography
Peyda. Styles `<size>/<weight>`: 32/48, 24/36 (mobile 20/30), 20/30, 16/32, 14/28, 12/24, 10/20; weights Regular/Medium/Bold(/Black). Buttons & labels: `14/Medium`; body `14/Regular` or `16/Regular`; helper `12/Regular`.