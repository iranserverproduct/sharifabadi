# IranServer UI Kit (Uikit-V3) — Component Catalog

Source: Figma file **Uikit-V3** (`0uxzan8L6i5bMtqwdjjOlX`), page **Cell & Component** (+ `Visual Asset`, `Section`). Extracted 2026-11-08 straight from the file (names/props are exact; anything marked [..] is an assumption).
Portal and Website both consume these as a **library**; instances are imported by key (`importComponentSetByKeyAsync`) — only *published* components can be imported.

Format: `Name | node id | key(8) | default variant size | properties`
Property legend: `X=a/b/c` variant property with options · `:bool` boolean (Show …) · `:text` text prop · `:swap` instance swap.
Variant naming convention (must be followed for anything new): `Name=…`, `Type=…`, `Status=…`, `State=…`, `Device=Desktop/Tablet/Mobile`; values like `Colored` / `B&W`; never `Mode`.

## 1. Core controls (use these first in the Portal)
```
Button | 7083:48352 | 1fa5fb3a | 138x42 | Show Right icon:bool ; Show Left icon:bool ; Title:text ; Type=Button/Icon Button ; Status=Tonal/Outline/Text/Primary/Link ; State=Default/Disable/Hover/Loading
Input | 6881:47965 | a4fdb287 | 350x106 | Show Description ; Show right icons ; Show left icons ; Show title icon ; Show Placeholder ; Show Button ; Show Error Icon ; Show Alert ; Show Pointer (all bool) ; Type=Default/Focus/Generate Password/Error/Disable/Button/With Dropdown/Open Dropdown
Text Area | 11555:1514 | 41f57f90 | 352x130 | Show icon/Show Description/Show send/Show title icon/Show attach_file/Show Placeholder/Show Chips (bool) ; Type=Default/Focus/Disable/Filled up/Default domain
Dropdown | 10443:14386 | 088152f6 | 332x74 | Type=Disable/Open/Multiple/Default/Type6/Text/Type8
Dropdown Cell | 10443:15708 | 6a59b9c4 | 237x32 | Type=Default
Search | 10660:5837 | 941945e5 | 746x42 | Type=Default/Disable/Fill/Focus/Typing
Domain Search | 10658:4890 | 97379def | 746x74 | Pro Search:bool ; Type=Fouces/Default/Loading
Date Picker | 10443:14516 | 70734920 | 340x74 | Type=Close/Open/Selected
Upload | 10310:690 | 1a8ae0b0 | 746x126 | Show Error ; Show description ; Type=Attached/Attached 2/Disable/Default
Counter | 20380:21733 | 785eaef3 | 418x74 | Title:text ; Label:text ; Show Label Icon ; Show Label ; State=Default/Disabled
Checkbox | 10443:15454 | 597297c0 | 162x32 | Show Content ; Show icon ; Show Space ; State=Checked/Intermediate/Unchecked ; Status=Default/Disable/Hover
Radio | 10443:15515 | 8fe0cb54 | 165x32 | Show Content ; Show icon ; Show Space ; State=On/Off ; Status=Default/Hover/Disable
Right Switcher | 10443:15548 | 27dd8811 | 175x28 | Show Content/Show Icon/Show Space ; State=Off/On ; Status=Active/Disable/Hover
Left Switcher | 12305:5808 | dab34019 | 191x28 | State=Off/On ; Status=Active/Disable/Hover
Switch Rounded | 21461:14640 | 81ede6ba | 371x36 | Count=1/2
Switch Cell Rounded | 21460:14624 | 802760af | 185x32 | State=False/True
Radio Card | 20365:13795 | 16919acf | 218x130 | Show Logo/Show Tag/Show Dropdown/Show Price/Show Discount Price/Show Options/Show Divider (bool) ; State=Selected/Default/Disabled
Chips | 10443:15678 | 7d1a4640 | 100x32 | Show Right Icon ; Show Left Icon ; Text:text ; State=Active/Deactive ; Size=Medium/Large
Tag | 10443:15660 | 45c0095f | 89x32 | Show left icon ; Show Right icon ; Title:text ; Show Title ; Color=Gray/Error/Info/Primary/Success/Warning/Secondary/Teritiary/Disabled/Surface ; Size=Small/Medium ; Type=Rounded/Square/Text
```

## 2. Navigation, feedback, overlays
```
Header | 10698:18174 | bd435d43 | (Section page) | Show Topbar ; Show Gift/Offer ; Show Searchbox (bool) ; Type=Header/Header [Open] ; Side=Dashboard/Site ; Device=Mobile/Tablet/Desktop ; No Login=False/True   ← Portal shell header = Side=Dashboard
Footer | 12440:4558 | 29218fc0 | | State=Site ; Device=Desktop/Mobile/Tablet ; Side=Site
Horizontal Tab | 15813:11462 | 30a84faf | 178x48 | Text:text ; State=Active/Deactive ; Size=Large/Small
Tab Cell | 10443:15688 | 99a9b590 | 237x38 | Counter ; Show Icon ; Show Tag ; Show Info (bool) ; Type=Active/Not active/Deactive
Tab-2 | 20004:20349 | a4cbaa9b | 276x44 | Title:text ; Show Tag/Show Counter/Show Right-Icon/Show Left-Icon ; Counter:text ; State=Active/Not-Active/Deactive ; Direction=LTR/RTL
Breadcrumb Cell | 10443:15742 | fb343a66 | 70x24 | Icon:bool ; Type=Active/Not active
Pagination | 14911:3214 | f7ec817d | 45x15 | Property 1=Pagination/Paginations/Default ; Property 2=Dot/Number ; Device=Desktop/Mobile
Sub menu Cell | 10443:15714 | 7e5c1b1f | 215x52 | Show Icon/Show Left Icon/Show Right Icon ; Type=Menu/Hover
Profile menu | 10443:14332 | 0a3dbbfe | 244x404 | Type=Default/Accounts List
Profile menu Cell | 10443:15762 | 49f9b360 | 262x44 | Show Icon ; Type=Default/Hover
Item Cell | 10443:15752 | 101c3a3c | 78x28 | Show Icon ; Type=Select & hover/Active   (operation-menu items)
Alert | 5958:45199 | 86e9e8fb | 970x52 | Show Right Icon/Show Button/Show Divider/Show Icon Button/Show Button-2/Show Divider-2 ; Type=Danger/Info/Success/Warning/Docs ; Device=Mobile/Desktop
Toast | 11744:2187 | 4d485df8 | 347x72 | Show Discription/Show Icon/Show Close icon ; Type=Error/Warning/Success/Info
Modal | 16565:3700 | 7dc37f21 | 564x578 | (single component; header/footer via Modal Cell)
Modal Cell | 11817:2129 | cfd281e3 | 538x96 | Show text/Show Button/Show Icon ; Type=Footer/Header
Tooltip | 14323:9074 | 7f4e3324 | 236x120 | (single)
Dropdown/Content | 22409:15859 | ba9151a1 | 332x350 | (single)
Empty State | 22612:26125 | 6a8cd804 | 932x250 | (single)   (+ Illustration set: "Empty State - No Result", "Empty State - Fliter")
Guidance | 23731:12934 | 71bdf46a | 1376x441 | Status=Primary/Success/Warning/Error/Info/Neutral ; Marker=Numbers/Dots
FAQ | 12758:1910 | 85e680f5 | 1320x68 | Title/Description/More Question:text ; Type=Close/Open/Go to Doc
Accordion | 11629:3091 | 6433b765 | 1392x52 | Type=Body/Header
Chat Bubble | 11853:2624 | 82429c00 | 398x104 | (single)
```

## 3. Tables & data
```
Table | 10443:14646 | 1a0fcc52 | 875x432 | Show Header:bool ; Type=Empty/Empty No Button/Empty One Button/Empty Three Button/Table
Table Cell | 10443:15640 | d260cd3e | 386x52 | Tag ; Show Text 1 ; Show Text 2 ; Description ; Show Right Icon [Header] ; Show Left Icon [Header] ; Show Left Icon [Body] ; Show Button ; Show Top (bool) ; Type=Content/Header/Content White/Content Gray ; State=Default/Hovered/Selected
Table Header | 22644:12902 | b4899973 | 386x52 | Tag/Show Label/Show Right Icon/Show Left Icon ; Tone=Brand/Neutral ; Title=Regular/Bold
Table Cell Master | 22644:13008 | bfd4578f | 386x88 | …Show Button/Show Top ; Tonal=Neutral/Pure White/Brand ; Title=Regular/Bold
Table Cell Price | 22605:12990 | e3e04bf6 | 386x62 | Show Discount/Show Period ; Type=Hover/White/Gray/Selected
Comparison Table | 22185:25343 | 7ca8de7e | 1320x570 | Device=Desktop/Tablet/Mobile   (+ [cell] sets: Comparison-Table [cell])
Text Cell | 10443:15604 | f2c1ff08 | 419x100 | Show Time/Show Divider ; Type=Read/Read [Hover]/Unread/Unread [Hover]   (notifications)
Search result Cell | 10443:15724 | 241439d9 | 443x64 | Description ; Show Button ; Change Button:swap ; Show Tag ; Change Tag:swap ; Type=Default/Hover
```

## 4. Pricing / plan / cards (mostly marketing website; reuse in Portal purchase flows only when UX responsibility fits)
```
Pricing-01 13438:2983 · Pricing-02 17612:20743 · Pricing-03 23782:14505 (Type=Default/Hover/Popular) · Pricing-04 18931:12986 · Pricing-05 18605:12467 · Pricing-06 20004:17754 · Pricing-07 21454:14522 · Responsive Pricing-07 21469:12425 · Pricing-sefareshi 14063:8136
Static Cards 19983:25597 (Device) · Hosting Services Card 20544:24705 (Type=Default/Popular/Other Offer ; Device) · Services Item 21311:11009 (Service's Type=Current/Higher/Lower) · Cycle-HostCard 21067:13980 (State=Opened/Closed/No Collapse) · Gift-Option 21067:13969 · Gift Tag 21455:12363 · Datacenter Card 21019:15825 (Type=Cities/Common ; State=Deactive/Active/Content Container ; Device) · App-Card 18538:11058 · Video-Card 18673:15078 · Solution Home Page Cards 21742:24317 · Customer Review 20523:22912 · Customer Logo 20523:22882 · Special Offer - Pricing 20159:10677
```

## 5. Visual assets (library)
- `Regular` (icon set, 190 icons, Material-style names e.g. `chevron_right`, `chevron_left`) `11930:2048` · `Bold` (88 icons, e.g. `Vertical`, `Ai`) `11930:2004` · `Bulk` (colour icons for services: Block Storage, Object Storage, CDN, VPS, Domain, Host, GPU, SSL …) `12863:9724` · `Glassy Icons` (service/brand logos with Size=56/48/40/16px) `20055:1384` · `Illustration` (hundreds; names like `Empty State - No Result`, `block-storage`, `Dedicated Hero`) `12484:2841` · `OS-logo` `17014:14554` · `Logo` `12475:2845`.
- Icons are instances (`Regular`/`Bold`/`Bulk`) with property `Name=<icon>`; resize icons per spec (Button icon 18px, Input icon 16px, Tag icon 16px, nav chevrons 28.8px).

## 6. Section library (website only)
`call-to-action-NN` and `content-NN` component sets (Device=Desktop/Tablet/Mobile) live on the Uikit-V3 **Section** page (frame "Content Section" `14941:7053`, "CTA Section"). Newest: `content-26` (GPU card + video slider, `23893:15416`). Not used in the Portal.

## 7. Portal-local components (Portal file `1qrZx6L5Ug2eniRA8epD2U`, NOT in the UI Kit)
These exist only in the Portal file. Reuse their *pattern* when prototyping; if a Figma prototype needs them, import from the Portal library.
```
Service Filter | 13884:23219 | 109x84 | Text:text ; Property 1=Default/Select           (category tiles on service list: همه / هاست / خدمات ابری …)
Services (Dashboard) 7329:10545 / 13113:15028 · Menu 7333:12590 / 7406:13146 / 13113:11614 (Type=Open/Close) · Price-plan 18033:29999 (Size=Desktop/Mobile/Tablet ; State=Default/Hovered)
Payment 10154:9396 (Type=Default/Discount open/Set discount/Wallet) · Wallet 36543:201460 (State=Wallet balance/Wallet Check/Disable/Loading/Cooldown/Rate limited) · Sidebar 36543:201512 (payment method side panel)
Common Actions 14728:8137 · Container (service-manage) 14574:6081 (Default/warning/Danger) · Bar chart 37570:73476 (Default/warning/Danger)
App-Card 19835:25075 · Plugin-Card 19837:29118 · CloudDisk-Card 19894:33206 · CPU-Ram Card 22509:67426 · CPU/RAM-Card 22523:70032 (Selected / Current Service)
Upgrade/Downgrade Type1 22582:61050 · CloudServer-Up/Down 22588:67554 (Device)
Block Storage / VPS purchase: Network Setting 25488:67997 · OS Section 24629:9846 · Cloud Storage 34062:95383 · Period 25198:12410 · Flavor Section 25389:68967 · Summary 33128:93449 · Summary Responsive 33151:93998 · Bottom Nav - Tablet/Mobile 24660:8751 / 24660:8881
Domain: Host Purchase_2 18221:20149 (State=Enter Domain/Have Domain/Epp/Submit Irnic/Success/…), Domain States (stepper dot) 33268:20279 (State=Pass/Current/Next/Warning/Error/Disable), Whois Information 20359:47320 (State=Pending/Edit - From Profile/Edit - Loading/Edit - Manual/Restricted/Edit - Error ; Size=Web/Tablet/Mobile ; Type=International/IR), DNS/NS/SSL/Lock cells (see Temp page)
Support: Attach File 11145:26778 · Dropdown 11180:5702 · Stars/Feedback · Accordion 12823:13150
Flowkit (flow/annotation blocks) on the Flowkit page.
```
Most-used UI Kit components across recent Portal pages (usage counts from the file): icons (Regular) ≫ Table Cell > Button > Tab Cell > Tag > Item Cell > Breadcrumb Cell > Service Filter > Sub menu > Input > Checkbox > Alert > Modal Cell > Toast > Pagination.
