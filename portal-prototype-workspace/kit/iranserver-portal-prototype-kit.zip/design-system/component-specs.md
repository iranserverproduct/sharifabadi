# Component specs (measured from Uikit-V3, 2026-11-08)

All colours are **semantic variables** (never raw hex in Figma). Hex shown only so an HTML prototype can reproduce them (`tokens.css` has them all). Font Peyda; Persian UI, RTL.

## Button (`Button`, 7083:48352) — single size, 42px
- Frame: **height 42**, horizontal auto-layout, padding **4 / 16 / 4 / 16**, gap 4, radius **8** (`Corner Radius/Medium`). Hug width (138 default w/ icons).
- Label: `14/Medium`. Icons 18×18 (optional left/right: props `Show Left icon`, `Show Right icon`).
- `Type=Button` (label button) or `Type=Icon Button` (42×42 square, pad 4, no label).
- `Status` (importance): 
  | Status | Default fill | Text | Hover fill | Disable |
  |---|---|---|---|---|
  | **Primary** | `Primary/Primary` #2635d9 | `Primary/On Primary` #fff | `Primary/On Primary Variant 2` #172082 | fill `Disable/Disable Container` #e4e5e7, text `Disable/On Disable` #7a7b85 |
  | **Tonal** | `Primary/Primary Container Variant 1` #dcebf9 | `Primary/Primary` | fill `Primary/Primary`, text `Primary/On Primary` | same as Primary disabled |
  | **Outline** | `Surface/Surface Bright` #fff + 1px stroke `Primary/Primary` | `Primary/Primary` | fill `Primary/Primary Container Variant 1` | stroke+text `Disable/On Disable` |
  | **Text** | no fill | `Primary/Primary` | fill `Primary/Primary Container Variant 1` | text `Disable/On Disable` |
  | **Link** | no fill, underline on hover (see Buttons.jpg) | `Primary/Primary` | underline | `Disable/On Disable` |
- `State=Loading`: becomes **42×42**, only a spinner (`Progress bar` 18px) in the status colour (white spinner on Primary).
- Design rules learned: **Primary is scarce** — one per view/step (the main forward action: «ادامه خرید», «خرید سرور ابری»). Secondary actions = Tonal or Outline (they look alike; Outline≈Tonal), tertiary = Text/Link. Footer pattern: Primary on the right (start in RTL), Text/Link «مرحله قبل» next to it. Reference image: `reference-docs/Buttons.jpg`.

## Input (`Input`, 6881:47965) — single height 42
Anatomy (vertical, gap 4): **Title row** (28px: optional 16px info icon + label `14/Medium`, colour `Surface/On Surface`) → **Field** (42px, h-layout, padding 8/12/8/12, radius 8, fill `Surface/Surface Bright`, 1px stroke) → **Helper/Description** (`12/Regular`, `Surface/On Surface Variant 4`, 24px line) or **Error** (red text + 16px error icon).
| Type | Stroke / fill | Notes |
|---|---|---|
| Default | stroke `Outline/Outline Varient` #cacace, fill white | placeholder `Show Placeholder`; optional left/right icons (e.g. eye for password) |
| Focus | stroke `Primary/Primary` 1px | caret visible (`Show Pointer`) |
| Error | stroke `Error/Error Container` #b01111 | helper becomes red error message with icon (`Show Error Icon`) |
| Disable | fill `Disable/Disable` #f4f4f5, label/text `Disable/On Disable` | |
| Also | `Generate Password`, `Button` (trailing button), `With Dropdown`, `Open Dropdown` | |
Reference image: `reference-docs/Input.jpg` (default, focus, error with eye icon, helper text).
Required marker: label ends with ` *` as seen on Login (`آدرس ایمیل *`).

## Tag (`Tag`) and Chips
- Tag: height 32 (Medium) / smaller (Small); padding 2/12 (Rounded) or 2/8 (Square); gap 4; **Rounded** radius 120 (pill, white fill + 1px `Outline/Outline`, used for feature lists with a ✓ right icon), **Square** radius 8 (status fill: e.g. Success = fill `Success/Success` #d8f3e3, green text), **Text** = no box. Colours: Gray, Error, Info, Primary, Success, Warning, Secondary, Teritiary, Disabled, Surface. Status tags in tables: فعال=Success, در انتظار / در حال پرداخت=Warning, در حال ایجاد=Info, (error)=Error.
- Chips (filter chips): height 32, `State=Active` filled primary-container w/ primary stroke, `Deactive` outlined; Size Medium/Large.

## Checkbox / Radio / Switch
Checkbox & Radio rows are 32px high with label; `State` (Checked/Intermediate/Unchecked | On/Off) × `Status` (Default/Hover/Disable). Switchers Right/Left (28px). `Radio Card` = selectable card with radio (used for OS / period / domain type choices; Selected state = primary 1px stroke + filled radio).

## Alert / Toast / Modal
Alert types `Danger/Info/Success/Warning/Docs` × Device (Desktop/Mobile); optional trailing buttons/dividers. Toast types `Error/Warning/Success/Info` 347×72 (title + optional description + close). Modal 564 wide (header/footer built with `Modal Cell`).

## Table (Portal)
Table frame: white `Factor list` card (radius 8, padding 24) → toolbar (search + filter icon-button + «خرید …» Primary button) → category tiles (`Service Filter`) → tabs (`Tab Cell`: Active/Not active/Deactive, optional counter/tag) → table container (radius 8, 1px `Outline/Outline Varient 2`) of `Table Cell` (Type=Header/Content; State Default/Hovered/Selected; row height ≥52; two-line cells with Text 1 + Text 2 e.g. name + `IP : 185.…`) → `Pagination` (Number; mobile shows condensed). Row actions = kebab icon → operation menu built from `Item Cell` (`Sub menu`); mobile table scrolls horizontally with sticky name column.

## Typography scale (text styles)
`32/Desktop` 32/48 (Black/Bold) · `24/Desktop & Tablet` 24/36 · `24/Mobile` 20/30 · `20` 20/30 · `16` 16/32 · `14` 14/28 · `12` 12/24 · `10` 10/20. Weights Regular, Medium, Bold (Black for 32/24). Page titles in Portal cards: 14–16 Bold in `Primary/On Primary Variant 3`; body 14; helper 12.

## Spacing / radius / stroke tokens
Gap: 05=2, 1=4, 2=8, 3=12, 4=16, 5=20, 6=24, 8=32, 10=40, 14=56, 16=64, 20=80, 22=88. Radius: Small 4, **Medium 8** (default for buttons, inputs, cards), Large 12, X-Large 40, Curve 120 (pills). Stroke: Small 1, Medium 1.5, Large 2. Shadow: `0 4 24` #2533cb @8% (rare).
