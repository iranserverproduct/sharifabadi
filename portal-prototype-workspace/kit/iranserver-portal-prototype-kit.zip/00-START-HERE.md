# راهنمای استفاده — کیت «پروتوتایپ پرتال ایران‌سرور»

این پکیج به یه Claude جدید یاد می‌ده PRD مدیر محصول رو بگیره و طبق **دیزاین سیستم ایران‌سرور (Uikit-V3)** و **پرتال** دیزاین/پروتوتایپ بسازه.

## ۵ مرحله‌ی راه‌اندازی
1. zip رو باز کن.
2. تو اکانت Claude جدید یه **Project** بساز (مثلاً «IranServer Portal Prototyping»).
3. **Project instructions** ← کل محتوای `01-PROJECT-INSTRUCTIONS.md` رو کپی/پیست کن.
4. **Project knowledge** ← این‌ها رو آپلود کن: پوشه‌های `design-system/`، `portal/`، `workflow/`، `prototype-starter/`، `reference-screens/`، `reference-docs/`.
5. (اختیاری ولی مهم برای Figma) **Figma MCP/Connector** رو وصل کن؛ اکانت Figma باید به این دو فایل دسترسی (Edit) داشته باشه و Uikit-V3 تو Portal به‌عنوان Library فعال باشه:
   - Portal: `1qrZx6L5Ug2eniRA8epD2U`
   - Uikit-V3: `0uxzan8L6i5bMtqwdjjOlX`
   - (برای لندینگ‌ها: Website `LuqQNLxinLogoKEgOCTwyr`)

## نحوه‌ی کار روزمره
تو یه چت داخل همون Project، PRD رو بچسبون (یا فایلش رو بده) و بنویس مثلاً:
> «این PRD رو بخون. طبق پرتال ایران‌سرور دیزاین بزن؛ اول خلاصه‌ی نیازمندی و فرض‌هات رو بگو، بعد دسکتاپ/تبلت/موبایل و stateها (خالی، لودینگ، خطا، موفق).»

اگه خروجی تعاملی می‌خوای بگو «**پروتوتایپ HTML** بزن» (از `prototype-starter/` استفاده می‌کنه)؛ اگه می‌خوای تو Figma باشه بگو «**تو فایل Portal** بساز».

## تو این پکیج چیه؟
| پوشه / فایل | کاربرد |
|---|---|
| `01-PROJECT-INSTRUCTIONS.md` | قواعد کاری و دیزاین (برای Project instructions) |
| `design-system/tokens.json·css·md` | همه‌ی رنگ‌ها، گپ‌ها، radius، تایپوگرافی (از خود فایل استخراج شده) |
| `design-system/components-catalog.md` | ۹۰+ کامپوننت UI Kit با ورینت و پراپرتی دقیق (Button, Input, Tag, Table Cell, Tab, Alert, Toast, Modal, …) + کامپوننت‌های لوکال پرتال |
| `design-system/component-specs.md` | اسپک اندازه‌گیری‌شده‌ی Button / Input / Tag / Table و قواعد استفاده |
| `portal/portal-patterns.md` | شِل پرتال، آرکی‌تایپ صفحه‌ها (لیست، ویزارد خرید، جزئیات، مالی، ورود…) و قراردادها |
| `workflow/prd-to-design-checklist.md` | چطور PRD رو تحلیل کنه + چه چیزهایی قبل از طراحی باید چک شه + شکاف‌های این کیت |
| `workflow/figma-gotchas.md` | نکات فنی کار با Figma MCP (RTL، sizing، variable، …) |
| `prototype-starter/` | CSS آماده‌ی پرتال + ۲ نمونه‌ی HTML (لیست سرویس، ورود) |
| `reference-screens/` | اسکرین‌شات‌های مرجع از پرتال و رندر استارتر |
| `reference-docs/` | مخاطب‌ها، اصول دیزاین، الگوها، overview سایت، تصاویر Button/Input |

## چه چیزی هنوز کامل نیست؟ (صادقانه)
- Modal/Toast/Support/Error و برخی صفحه‌های مالی فقط در حد کامپوننت و اسکرین‌شات بررسی شدن، نه اندازه‌گیری دقیق؛ تو `portal-patterns.md` با `[?]` علامت خورده.
- راهنمای نوشتاری (microcopy) مکتوب وجود نداره؛ Claude از صفحه‌های موجود الگوبرداری می‌کنه.
- رنگ دقیق متن بعضی Tagها و استپر تو استارتر HTML تقریبیه.
- فونت Peyda تو Google Fonts نیست؛ تو HTML از Vazirmatn به‌عنوان جایگزین استفاده شده. اگه فایل Peyda داری بده تا embed بشه.
- Library access و publish بودن کامپوننت‌ها تو اکانت جدید باید چک شه (بدون publish، import با key کار نمی‌کنه).

## یادآوری
- حافظه‌ی خودکار این اکانت منتقل نمی‌شه؛ قواعد مهمش تو instructions اومده.
- اگه بعداً Uikit یا Portal عوض شد، بگو «کاتالوگ رو از روی فایل دوباره استخراج کن».
